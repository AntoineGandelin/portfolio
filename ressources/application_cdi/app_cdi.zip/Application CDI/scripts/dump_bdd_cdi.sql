--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: eleve; Type: TABLE; Schema: public; Owner: cdi_admin
--

CREATE TABLE public.eleve (
    id_eleve integer NOT NULL,
    nom_eleve character varying(20) NOT NULL,
    prenom_eleve character varying(20) NOT NULL,
    classe character varying(10) NOT NULL
);


ALTER TABLE public.eleve OWNER TO cdi_admin;

--
-- Name: horaire; Type: TABLE; Schema: public; Owner: cdi_admin
--

CREATE TABLE public.horaire (
    id_horaire integer NOT NULL,
    date character varying(10) NOT NULL,
    heure character varying(10) NOT NULL
);


ALTER TABLE public.horaire OWNER TO cdi_admin;

--
-- Name: presence; Type: TABLE; Schema: public; Owner: cdi_admin
--

CREATE TABLE public.presence (
    id_presence integer NOT NULL,
    classe character varying(10) NOT NULL,
    nom_eleve character varying(20) NOT NULL,
    date character varying(10) NOT NULL,
    heure character varying(10) NOT NULL,
    activite character varying(20) NOT NULL
);


ALTER TABLE public.presence OWNER TO cdi_admin;

--
-- Data for Name: eleve; Type: TABLE DATA; Schema: public; Owner: cdi_admin
--

INSERT INTO public.eleve VALUES (0, 'Pattin', 'Mélie', '5A');
INSERT INTO public.eleve VALUES (1, 'Guillemin', 'Camille', '5A');
INSERT INTO public.eleve VALUES (2, 'Rodrigues', 'Maelys', '5C');
INSERT INTO public.eleve VALUES (3, 'Fesson', 'Iliana', '5C');
INSERT INTO public.eleve VALUES (4, 'Ronveaux', 'Méline', '5A');
INSERT INTO public.eleve VALUES (5, 'Joste', 'Chloé', '5C');
INSERT INTO public.eleve VALUES (6, 'Blarasin', 'Noé', '5C');
INSERT INTO public.eleve VALUES (7, 'Lechene', 'Mathéo', '5C');
INSERT INTO public.eleve VALUES (8, 'Brasseur', 'Colombe', '5C');
INSERT INTO public.eleve VALUES (9, 'Ponsard', 'Maellys', '5C');
INSERT INTO public.eleve VALUES (10, 'Arnaise', 'Noé', '5A');
INSERT INTO public.eleve VALUES (11, 'Gravier', 'Louka', '5A');
INSERT INTO public.eleve VALUES (13, 'Mandelli', 'Nathanael', '5C');
INSERT INTO public.eleve VALUES (14, 'Da Cruz', 'Miguel', '5C');
INSERT INTO public.eleve VALUES (15, 'Ternois', 'Mathéo', '5A');
INSERT INTO public.eleve VALUES (16, 'Rousseaux', 'Chris', '5C');
INSERT INTO public.eleve VALUES (17, 'Renaud', 'Chloé', '5C');
INSERT INTO public.eleve VALUES (18, 'Leroux', 'Evy', '5C');
INSERT INTO public.eleve VALUES (19, 'Bossuet', 'Clovis', '5C');
INSERT INTO public.eleve VALUES (20, 'Grognet', 'Clément', '5A');
INSERT INTO public.eleve VALUES (21, 'Lallement', 'Yolan', '5C');
INSERT INTO public.eleve VALUES (12, 'Lesur', 'Mathias', '5C');
INSERT INTO public.eleve VALUES (22, 'Vaireaux', 'Océane', '3B');
INSERT INTO public.eleve VALUES (23, 'Longhini', 'Camille', '3B');
INSERT INTO public.eleve VALUES (24, 'Thiebaut', 'Charlotte', '4C');
INSERT INTO public.eleve VALUES (25, 'Roland', 'Thomas', '4C');
INSERT INTO public.eleve VALUES (26, 'Gilmaire', 'Luis', '4C');
INSERT INTO public.eleve VALUES (27, 'Lefevre', 'Hugo', '4C');
INSERT INTO public.eleve VALUES (28, 'Auriol', 'Mathis', '4C');
INSERT INTO public.eleve VALUES (29, 'Gely', 'Kody', '4C');
INSERT INTO public.eleve VALUES (30, 'Jacques', 'Julien', '6B');
INSERT INTO public.eleve VALUES (31, 'Bertrand', 'Jean', '5A');
INSERT INTO public.eleve VALUES (32, 'Haas', 'Arthus', '5A');
INSERT INTO public.eleve VALUES (33, 'Macquart', 'Annaella', '6C');
INSERT INTO public.eleve VALUES (34, 'Curé', 'Mayllis', '6C');
INSERT INTO public.eleve VALUES (35, 'Leverd', 'Thomas', '6B');
INSERT INTO public.eleve VALUES (36, 'Dupays', 'Rayan', '6B');
INSERT INTO public.eleve VALUES (37, 'Peltier', 'Nina', '5A');
INSERT INTO public.eleve VALUES (38, 'Fraiture', 'Antoine', '6A');
INSERT INTO public.eleve VALUES (39, 'Guillaume', 'Damien', '4B');
INSERT INTO public.eleve VALUES (40, 'Robinet', 'Clara', '5A');
INSERT INTO public.eleve VALUES (41, 'Chmura', 'Naelle', '5A');
INSERT INTO public.eleve VALUES (42, 'Baudesson', 'Kigan', '4B');
INSERT INTO public.eleve VALUES (43, 'Hernoux', 'Enzo', '4B');
INSERT INTO public.eleve VALUES (44, 'Pinho', 'Diego', '6B');
INSERT INTO public.eleve VALUES (45, 'Longhini', 'Benjamin', '6B');
INSERT INTO public.eleve VALUES (46, 'Guillaume', 'Sohann', '6B');
INSERT INTO public.eleve VALUES (47, 'Linden', 'Elsa', '6C');
INSERT INTO public.eleve VALUES (48, 'Pignaut', 'Clara', '6C');
INSERT INTO public.eleve VALUES (49, 'Poulain', 'Jeanne', '6C');
INSERT INTO public.eleve VALUES (50, 'Dufour', 'Louise', '4A');
INSERT INTO public.eleve VALUES (51, 'Hajewski', 'Lucie', '4A');
INSERT INTO public.eleve VALUES (52, 'Dusard', 'Louize', '4A');
INSERT INTO public.eleve VALUES (53, 'Carbon', 'Lana', '3C');
INSERT INTO public.eleve VALUES (54, 'Brault', 'Emma', '3C');
INSERT INTO public.eleve VALUES (55, 'Gouraud', 'Elza', '3C');
INSERT INTO public.eleve VALUES (56, 'Lechene', 'Morgane', '3C');
INSERT INTO public.eleve VALUES (57, 'Gout', 'Lauryn', '3C');
INSERT INTO public.eleve VALUES (58, 'Payet', 'Wendy', '3C');
INSERT INTO public.eleve VALUES (59, 'Dufour', 'Louise', '4A');
INSERT INTO public.eleve VALUES (60, 'Delille', 'Arthur', '4A');
INSERT INTO public.eleve VALUES (61, 'Dazy', 'Ethan', '4A');
INSERT INTO public.eleve VALUES (62, 'Baudelot', 'Xavier', '4A');
INSERT INTO public.eleve VALUES (63, 'Delaisse', 'Noan', '4A');
INSERT INTO public.eleve VALUES (64, 'Macquart', 'Alexis', '4A');
INSERT INTO public.eleve VALUES (65, 'Decours', 'Mathis', '3C');
INSERT INTO public.eleve VALUES (66, 'Dupont', 'Owen', '3C');
INSERT INTO public.eleve VALUES (67, 'Lambert', 'Sullivan', '3C');
INSERT INTO public.eleve VALUES (68, 'Dussart', 'Justin', '3C');
INSERT INTO public.eleve VALUES (69, 'Ronveaux', 'Mélina', '5A');
INSERT INTO public.eleve VALUES (70, 'Villedieu', 'Noeline', '5A');
INSERT INTO public.eleve VALUES (71, 'Piette', 'Chloé', '5A');
INSERT INTO public.eleve VALUES (72, 'Lallemant', 'Neela', '5A');
INSERT INTO public.eleve VALUES (73, 'Chalenton', 'Shelsy', '5A');
INSERT INTO public.eleve VALUES (74, 'Rodrigues', 'Maelys', '5C');
INSERT INTO public.eleve VALUES (75, 'Mozet', 'Carla', '3C');
INSERT INTO public.eleve VALUES (76, 'Payet', 'Wendy', '3C');
INSERT INTO public.eleve VALUES (77, 'Pivetta', 'Mattis', '5B');
INSERT INTO public.eleve VALUES (78, 'Barragatto', 'Maeva', '5B');
INSERT INTO public.eleve VALUES (79, 'Chaslin', 'Auxane', '5B');
INSERT INTO public.eleve VALUES (80, 'Boubkar', 'Inaya', '5B');
INSERT INTO public.eleve VALUES (81, 'Magny', 'Juliette', '5B');
INSERT INTO public.eleve VALUES (82, 'Bousquet', 'Rebecca', '5B');
INSERT INTO public.eleve VALUES (83, 'Suppin', 'Elise', '5B');
INSERT INTO public.eleve VALUES (84, 'Benetuly', 'Océane', '5B');
INSERT INTO public.eleve VALUES (85, 'Remy', 'Mathéo', '5B');
INSERT INTO public.eleve VALUES (86, 'Chaslin', 'Auxane', '5B');
INSERT INTO public.eleve VALUES (87, 'Bousquet', 'Rebecca', '5B');
INSERT INTO public.eleve VALUES (88, 'Barragatto', 'Maeva', '5B');
INSERT INTO public.eleve VALUES (89, 'Suppin', 'Elise', '5B');
INSERT INTO public.eleve VALUES (90, 'Trouslaid', 'Alexandre', '5B');
INSERT INTO public.eleve VALUES (91, 'Kutter', 'Quentin', '5B');
INSERT INTO public.eleve VALUES (92, 'Gillemène', 'Luis', '4C');
INSERT INTO public.eleve VALUES (93, 'Delille', 'Arthur', '4A');
INSERT INTO public.eleve VALUES (94, 'Auriol', 'Mattis', '4C');
INSERT INTO public.eleve VALUES (95, 'Avelange', 'Baptiste', '4A');
INSERT INTO public.eleve VALUES (96, 'Richard', 'Lucia', '4A');
INSERT INTO public.eleve VALUES (97, 'Hajewski', 'Lucie', '4A');
INSERT INTO public.eleve VALUES (98, 'Vacher', 'Lena', '4A');
INSERT INTO public.eleve VALUES (99, 'Dupays', 'Rayan', '6B');
INSERT INTO public.eleve VALUES (100, 'Raux', 'Maxence', '6B');
INSERT INTO public.eleve VALUES (101, 'Faye', 'Tom', '6B');
INSERT INTO public.eleve VALUES (102, 'Longhini', 'Benjamin', '6B');
INSERT INTO public.eleve VALUES (103, 'Ferreira', 'Léa', '6B');
INSERT INTO public.eleve VALUES (104, 'Cugnet', 'Louise', '6B');
INSERT INTO public.eleve VALUES (105, 'Gomes', 'Maeva', '6B');
INSERT INTO public.eleve VALUES (106, 'Pinho', 'Diego', '6B');
INSERT INTO public.eleve VALUES (107, 'Jacquot', 'Wendy', '6B');
INSERT INTO public.eleve VALUES (108, 'Crippa J', 'Clara', '6D');
INSERT INTO public.eleve VALUES (109, 'Picart', 'Florent', '6D');
INSERT INTO public.eleve VALUES (110, 'Gridaine', 'Leo', '6D');
INSERT INTO public.eleve VALUES (111, 'Gridaine', 'Mathéo', '6D');
INSERT INTO public.eleve VALUES (112, 'Callaloria', 'Stan', '6D');
INSERT INTO public.eleve VALUES (113, 'Leclef', 'Mathis', '6A');
INSERT INTO public.eleve VALUES (114, 'Panis', 'Morgane', '6D');
INSERT INTO public.eleve VALUES (115, 'Monoi', 'Nina', '6A');
INSERT INTO public.eleve VALUES (116, 'Ciach', 'Jelena', '6A');
INSERT INTO public.eleve VALUES (117, 'Hbib', 'Amira', '6A');
INSERT INTO public.eleve VALUES (118, 'Discrit', 'Lilou', '6D');
INSERT INTO public.eleve VALUES (119, 'Roland', 'Myla', '6A');
INSERT INTO public.eleve VALUES (120, 'Jadot', 'Maëlys', '6A');


--
-- Data for Name: horaire; Type: TABLE DATA; Schema: public; Owner: cdi_admin
--

INSERT INTO public.horaire VALUES (0, '2021-06-14', 'M1');
INSERT INTO public.horaire VALUES (1, '2021-06-14', 'M2');
INSERT INTO public.horaire VALUES (2, '2021-06-14', 'M3');
INSERT INTO public.horaire VALUES (3, '2021-06-14', 'M4');
INSERT INTO public.horaire VALUES (4, '2021-06-14', 'S1');
INSERT INTO public.horaire VALUES (5, '2021-06-14', 'S2');
INSERT INTO public.horaire VALUES (6, '2021-06-14', 'S3');
INSERT INTO public.horaire VALUES (7, '2021-06-17', 'M3');
INSERT INTO public.horaire VALUES (8, '2021-06-18', 'M2');
INSERT INTO public.horaire VALUES (9, '2021-06-21', 'M1');
INSERT INTO public.horaire VALUES (10, '2021-06-22', 'S2');


--
-- Data for Name: presence; Type: TABLE DATA; Schema: public; Owner: cdi_admin
--

INSERT INTO public.presence VALUES (1, '5A', 'Guillemin Camille', '18/06/2021', 'M4', 'Table');
INSERT INTO public.presence VALUES (2, '5A', 'Ronveaux Mélina', '18/06/2021', 'M4', 'Table');
INSERT INTO public.presence VALUES (3, '5A', 'Villedieu Noeline', '18/06/2021', 'M4', 'Table');
INSERT INTO public.presence VALUES (4, '5A', 'Piette Chloé', '18/06/2021', 'M4', 'Table');
INSERT INTO public.presence VALUES (5, '5A', 'Lallemant Neela', '18/06/2021', 'M4', 'Table');
INSERT INTO public.presence VALUES (6, '5C', 'Joste Chloé', '18/06/2021', 'M4', 'Table');
INSERT INTO public.presence VALUES (7, '5A', 'Chalenton Shelsy', '18/06/2021', 'M4', 'Table');
INSERT INTO public.presence VALUES (8, '5C', 'Rodrigues Maelys', '18/06/2021', 'M4', 'Table');
INSERT INTO public.presence VALUES (9, '5C', 'Lesur Mathias', '18/06/2021', 'M4', 'PC');
INSERT INTO public.presence VALUES (10, '5A', 'Grognet Clément', '18/06/2021', 'M4', 'PC');
INSERT INTO public.presence VALUES (11, '5C', 'Rousseaux Chris', '18/06/2021', 'M4', 'PC');
INSERT INTO public.presence VALUES (12, '5A', 'Ternois Mathéo', '18/06/2021', 'M4', 'Lecture');
INSERT INTO public.presence VALUES (13, '5C', 'Mandelli Nathanael', '18/06/2021', 'M4', 'PC');
INSERT INTO public.presence VALUES (14, '3C', 'Mozet Carla', '21/06/2021', 'M1', 'Table');
INSERT INTO public.presence VALUES (15, '3C', 'Payet Wendy', '21/06/2021', 'M1', 'Table');
INSERT INTO public.presence VALUES (16, '5B', 'Pivetta Mattis', '21/06/2021', 'S2', 'Table');
INSERT INTO public.presence VALUES (17, '5B', 'Barragatto Maeva', '21/06/2021', 'S2', 'Table');
INSERT INTO public.presence VALUES (18, '5B', 'Chaslin Auxane', '21/06/2021', 'S2', 'Table');
INSERT INTO public.presence VALUES (19, '5B', 'Boubkar Inaya', '21/06/2021', 'S2', 'Table');
INSERT INTO public.presence VALUES (20, '5B', 'Magny Juliette', '21/06/2021', 'S2', 'Table');
INSERT INTO public.presence VALUES (21, '5B', 'Bousquet Rebecca', '21/06/2021', 'S2', 'Table');
INSERT INTO public.presence VALUES (22, '5B', 'Suppin Elise', '21/06/2021', 'S2', 'Table');
INSERT INTO public.presence VALUES (23, '5B', 'Benetuly Océane', '21/06/2021', 'S2', 'Table');
INSERT INTO public.presence VALUES (24, '5B', 'Remy Mathéo', '21/06/2021', 'S2', 'Lecture');
INSERT INTO public.presence VALUES (25, '5B', 'Chaslin Auxane', '22/06/2021', 'S1', 'Table');
INSERT INTO public.presence VALUES (26, '5B', 'Bousquet Rebecca', '22/06/2021', 'S1', 'Table');
INSERT INTO public.presence VALUES (27, '5B', 'Barragatto Maeva', '22/06/2021', 'S1', 'Table');
INSERT INTO public.presence VALUES (28, '5B', 'Suppin Elise', '22/06/2021', 'S1', 'Table');
INSERT INTO public.presence VALUES (29, '5B', 'Trouslaid Alexandre', '22/06/2021', 'S1', 'Table');
INSERT INTO public.presence VALUES (30, '5B', 'Kutter Quentin', '22/06/2021', 'S1', 'Table');
INSERT INTO public.presence VALUES (31, '4C', 'Gillemène Luis', '22/06/2021', 'S1', 'PC');
INSERT INTO public.presence VALUES (32, '4A', 'Delille Arthur', '22/06/2021', 'S1', 'PC');
INSERT INTO public.presence VALUES (33, '4C', 'Auriol Mathis', '22/06/2021', 'S1', 'PC');
INSERT INTO public.presence VALUES (34, '4A', 'Avelange Baptiste', '22/06/2021', 'S1', 'Lecture');
INSERT INTO public.presence VALUES (35, '4A', 'Richard Lucia', '22/06/2021', 'S1', 'Lecture');
INSERT INTO public.presence VALUES (36, '4A', 'Hajewski Lucie', '22/06/2021', 'S1', 'Lecture');
INSERT INTO public.presence VALUES (37, '4A', 'Vacher Lena', '22/06/2021', 'S1', 'Lecture');
INSERT INTO public.presence VALUES (38, '6B', 'Dupays Rayan', '22/06/2021', 'S2', 'PC');
INSERT INTO public.presence VALUES (39, '6B', 'Raux Maxence', '22/06/2021', 'S2', 'PC');
INSERT INTO public.presence VALUES (40, '6B', 'Faye Tom', '22/06/2021', 'S2', 'PC');
INSERT INTO public.presence VALUES (41, '6B', 'Longhini Benjamin', '22/06/2021', 'S2', 'Lecture');
INSERT INTO public.presence VALUES (42, '6B', 'Ferreira Léa', '22/06/2021', 'S2', 'Lecture');
INSERT INTO public.presence VALUES (43, '6B', 'Cugnet Louise', '22/06/2021', 'S2', 'Lecture');
INSERT INTO public.presence VALUES (44, '6B', 'Gomes Maeva', '22/06/2021', 'S2', 'Lecture');
INSERT INTO public.presence VALUES (45, '6B', 'Pinho Diego', '22/06/2021', 'S2', 'Lecture');
INSERT INTO public.presence VALUES (46, '6B', 'Jacquot Wendy', '22/06/2021', 'S2', 'Lecture');
INSERT INTO public.presence VALUES (47, '6D', 'Crippa J Clara', '22/06/2021', 'S3', 'Table');
INSERT INTO public.presence VALUES (48, '6D', 'Picart Florent', '22/06/2021', 'S3', 'Table');
INSERT INTO public.presence VALUES (49, '6D', 'Gridaine Leo', '22/06/2021', 'S3', 'Table');
INSERT INTO public.presence VALUES (50, '6D', 'Gridaine Mathéo', '22/06/2021', 'S3', 'Table');
INSERT INTO public.presence VALUES (51, '6D', 'Callaloria Stan', '22/06/2021', 'S3', 'Table');
INSERT INTO public.presence VALUES (52, '6A', 'Leclef Mathis', '22/06/2021', 'S3', 'Table');
INSERT INTO public.presence VALUES (53, '6D', 'Panis Morgane', '22/06/2021', 'S3', 'Table');
INSERT INTO public.presence VALUES (54, '6A', 'Monoi Nina', '22/06/2021', 'S3', 'PC');
INSERT INTO public.presence VALUES (55, '6A', 'Ciach Jelena', '22/06/2021', 'S3', 'PC');
INSERT INTO public.presence VALUES (56, '6A', 'Hbib Amira', '22/06/2021', 'S3', 'PC');
INSERT INTO public.presence VALUES (57, '6D', 'Discrit Lilou', '22/06/2021', 'S3', 'PC');
INSERT INTO public.presence VALUES (58, '6A', 'Roland Myla', '22/06/2021', 'S3', 'PC');
INSERT INTO public.presence VALUES (59, '6A', 'Jadot Maëlys', '22/06/2021', 'S3', 'PC');
INSERT INTO public.presence VALUES (0, '5A', 'Pattin Mélie', '18/06/2021', 'M4', 'Table');


--
-- Name: eleve eleve_pkey; Type: CONSTRAINT; Schema: public; Owner: cdi_admin
--

ALTER TABLE ONLY public.eleve
    ADD CONSTRAINT eleve_pkey PRIMARY KEY (id_eleve);


--
-- Name: horaire horaire_pkey; Type: CONSTRAINT; Schema: public; Owner: cdi_admin
--

ALTER TABLE ONLY public.horaire
    ADD CONSTRAINT horaire_pkey PRIMARY KEY (id_horaire);


--
-- Name: presence presence_pkey; Type: CONSTRAINT; Schema: public; Owner: cdi_admin
--

ALTER TABLE ONLY public.presence
    ADD CONSTRAINT presence_pkey PRIMARY KEY (id_presence);


--
-- PostgreSQL database dump complete
--

