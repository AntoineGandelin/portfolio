create database cdi;
create role cdi_admin password 'admin' login;
grant all on database cdi to cdi_admin;