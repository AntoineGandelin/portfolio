begin transaction;

create table eleve
	(
	id_eleve			integer			primary key,
	nom_eleve			varchar(20)		not null,
	prenom_eleve		varchar(20)		not null,
	classe				varchar(10)		not null
	);

create table horaire
	(
	id_horaire 		integer 		primary key,
	date 			varchar(10) 	not null,
	heure 			varchar(10) 	not null
	);

create table presence
	(
	id_presence 	integer 		primary key,
	classe 			varchar(10) 	not null,
	nom_eleve 		varchar(20) 	not null,
	date 			varchar(10) 	not null,
	heure 			varchar(10) 	not null,
	activite 		varchar(20) 	not null
	);

commit;