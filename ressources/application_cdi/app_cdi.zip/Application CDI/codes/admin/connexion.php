<!DOCTYPE html>
<html>
	<head>
		<title>Application - CDI</title>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8">
		<meta http-equiv="content-style-type" content="text/css">
		<link href="connexion.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<header>
			<h1>Application - CDI : Connexion</h1>
		</header>
		<main>
			<div id="p2">
				Pour vous connecter, remplissez le formulaire ci-dessous :
			</div>
			<br>
				<div id="connect">			
				<form method="get" action="connexion_go.php">
	    			<article class="description">
	    			Identifiant : <input type="text" name="login" required>  
	   		 		</article>
	    			<article class="description">
	    			Mot de passe : <input type="password" name="mdp" required>			
				</article>
	    			<input type="submit" value="Se connecter">
				</form>
				</div>