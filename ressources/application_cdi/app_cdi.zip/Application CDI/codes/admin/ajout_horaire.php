<!DOCTYPE html>
<html>
	<head>
		<title>Application - CDI</title>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8">
		<meta http-equiv="content-style-type" content="text/css">
		<link href="ajout_horaire.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<header>
			<h1>Application - CDI : Ajouter un horaire</h1>
		</header>
		<main>
		<div id="p2">
			Pour ajouter un horaire, veuillez remplir les informations ci-dessous :
		</div>
		<br>
			<form action="ajout_horaire_go.php" method="get">
				<table>
					<tr><td class="droite">Date :</td><td><input type="date" name="date" required></td></tr>
					<tr><td class="droite">Heure :</td><td><input type="text" name="heure"></td></tr>
					<tr><td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp ➔</td><td><input type="submit" value="Ajouter l'horaire"></td></tr>
					<tr><td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp ➔</td><td><input type="reset" value="Réinitialiser"></td></tr>
				</table>
			</form>
			<br>
			<div id="bouton">
				<button class="cyan" onclick="window.location.href='accueil_admin.php';">Retourner à la page d'accueil</button>
			</div>
		</main>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<footer>
			<div id="copyright">
				© Antoine GANDELIN - Tous droits réservés - 2021
			</div>
		</footer>
	</body>
</html>