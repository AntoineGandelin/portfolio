<!DOCTYPE html>
<html>

<head>
	<title>Application - CDI</title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8">
	<meta http-equiv="content-style-type" content="text/css">
	<link href="affectation_eleve.css" rel="stylesheet" type="text/css">
</head>

<body>
	<header>
		<h1>Application - CDI : Affecter un élève</h1>
	</header>
	<main>
		<div id="p2">
			Pour noter la présence d'un élève au CDI, veuillez remplir les informations ci-dessous :
		</div>
		<br>
		<form action="affectation_eleve_go.php" method="post">
			<?php
			$conn = pg_connect('host=127.0.0.1 dbname=cdi user=cdi_admin password=admin');
			$chaine_req = 'SELECT distinct classe FROM eleve ORDER BY classe';
			$req = pg_query($chaine_req);
			$ligne = pg_fetch_all($req);
			echo '<select name = "classe">';
			echo '<option>Classe de l\'élève :</option>';
			foreach ($ligne as $value) 
				{
				echo '<option>'.$value['classe'].'</option>';
				}
			echo '</select>';
			pg_close($conn);
			?>

			<br>
			<br>

			<?php
			$conn = pg_connect('host=127.0.0.1 dbname=cdi user=cdi_admin password=admin');
			$chaine_req = 'SELECT distinct nom_eleve,prenom_eleve FROM eleve ORDER BY nom_eleve';
			$req = pg_query($chaine_req);
			$ligne = pg_fetch_all($req);
			echo '<select name="nom_eleve">';
			echo '<option>Nom/Prénom de l\'élève :</option>';
			foreach ($ligne as $value) 
				{
				echo '<option>'.$value['nom_eleve'].' '.$value['prenom_eleve'].'</option>';
				}
			echo '</select>';
			pg_close($conn);
			?>

			<br>
			<br>

			<?php
			$conn = pg_connect('host=127.0.0.1 dbname=cdi user=cdi_admin password=admin');
			$chaine_req = 'SELECT distinct date FROM horaire ORDER BY date';
			$req = pg_query($chaine_req);
			$ligne = pg_fetch_all($req);

			echo '<select name = "date">';
			echo '<option>Date :</option>';
			foreach ($ligne as $value) 
				{
				$date_format = new DateTime($value['date']);
				echo '<option>'.$date_format->format('d/m/Y').'</option>';
				}
			echo '</select>';
			pg_close($conn);
			?>

			<br>
			<br>

			<?php
			$conn = pg_connect('host=127.0.0.1 dbname=cdi user=cdi_admin password=admin');
			$chaine_req = 'SELECT distinct heure FROM horaire ORDER BY heure';
			$req = pg_query($chaine_req);
			$ligne = pg_fetch_all($req);
			echo '<select name="heure">';
			echo '<option>Heure :</option>';
			foreach ($ligne as $value) 
				{
				echo '<option>'.$value['heure'].'</option>';
				}
			echo '</select>';
			pg_close($conn);
			?>

			<br>
			<br>

			<select name="activite">
			<option> Activité de l'élève : </option>
			<option>PC</option>
			<option>Lecture</option>
			<option>Table</option>
			</select>
			<br>
			<br>
			<input type="submit" value="Enregistrer"></input>
			<input type="reset" value="Réinitialiser"></input>
			</input>
		</form>
		<br>

		<div id="bouton">
			<button class="cyan" onclick="window.location.href='accueil_admin.php';">Retourner à la page d'accueil</button>
		</div>

	</main>

	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>

	<footer>
		<div id="copyright">
			© Antoine GANDELIN - Tous droits réservés - 2021
		</div>
	</footer>

</body>

</html>