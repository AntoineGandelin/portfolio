<?php
	$nom_eleve = $_GET['nom'];
	$prenom_eleve = $_GET['prenom'];
    $classe = $_GET['classe'];
	$conn = pg_connect('host=127.0.0.1 dbname=cdi user=cdi_admin password=admin');
	$chaine_req = 'insert into eleve (id_eleve, nom_eleve, prenom_eleve, classe)  values ((select count(id_eleve) from eleve), '."'".$nom_eleve."', '".$prenom_eleve."', '".$classe."')"; 
	$req = pg_query($chaine_req);
	pg_close($conn);
	if($req)
		{
		echo 'L\'élève a bien été ajouté.';
		}
	else 
		{
		echo 'Erreur : L\'élève n\'a pas été ajouté ou existe déjà.';
		}
	echo '<br /><a href="ajout_eleve.php">Revenir à la page d\'ajout d\'un élève.</a>';
	echo '<br /><a href="accueil_admin.php">Revenir à la page d\'accueil.</a>';
?>