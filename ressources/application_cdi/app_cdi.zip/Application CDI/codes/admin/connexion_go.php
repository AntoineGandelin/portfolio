<?php
	session_start();
	$conn = pg_connect('host=127.0.0.1 dbname=cdi user=cdi_admin password=admin');
	$login = pg_escape_literal($conn, $_GET['login']);
	$pass = pg_escape_literal(md5($_GET['mdp']));
	$chaine_req = 'select * from connexion where login='.$login.' and pass='.$pass;
	$req = pg_query($chaine_req);
	pg_close($conn);
		
	if($req)
		{
		$_SESSION['login'] = $_GET['login'];
		echo 'Bienvenue '.$_SESSION['login'].'. Vous êtes bien connecté !';
		echo '<br><a href="accueil_admin.php?id='.$_GET['login'].'">Revenir à la page d\'accueil.</a>';
		}
	else 
		{
		echo 'Erreur : La connexion a échoué. ';
        echo '<br>';
		echo '<a href="connexion.php">Revenir à la page de connexion</a>';
		echo '<br>';
		echo '<a href="accueil_admin.php">Revenir à la page d\'accueil</a>';
		}
?>