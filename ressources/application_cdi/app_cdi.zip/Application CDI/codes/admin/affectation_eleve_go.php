<?php
    $classe = $_POST['classe'];
	$nom_eleve = $_POST['nom_eleve'];
	$date = $_POST['date'];
	$heure = $_POST['heure'];
	$activite = $_POST['activite'];
	$conn = pg_connect('host=127.0.0.1 dbname=cdi user=cdi_admin password=admin');
	$chaine_req = 'insert into presence (id_presence, classe, nom_eleve, date, heure, activite) values ((select count(id_presence) from presence), '."'".$classe."', '".$nom_eleve."', '".$date."', '".$heure."', '".$activite."')"; 
	$req = pg_query($chaine_req);
	pg_close($conn);
	if($req)
		{
		echo 'L\'élève a bien été affecté.';
		}
	else 
		{
		echo 'Erreur : L\'élève n\'a pas été ou est déjà affecté.';
		}
	echo '<br /><a href="affectation_eleve.php">Revenir à la page d\'affectation d\'un élève.</a>';
	echo '<br /><a href="accueil_admin.php">Revenir à la page d\'accueil.</a>';
?>