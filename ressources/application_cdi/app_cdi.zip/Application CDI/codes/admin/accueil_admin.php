<!DOCTYPE html>
<html>
	<head>
		<title>Application - CDI</title>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8">
		<meta http-equiv="content-style-type" content="text/css">
		<link href="accueil_admin.css" rel="stylesheet" type="text/css">
		</script>
	</head>
	<body>
		<header>
			<h1>Application - CDI : Accueil (Administrateur)</h1>
		</header>
		<main>
			<p>Bienvenue sur la page d'accueil "Administrateur" !</p>
			<div id="bouton">
				<button class="cyan" onclick="window.location.href='http://localhost/phppgadmin/';">Gérer la base de données</button>
			<br>
				<button class="cyan" onclick="window.location.href='https://sites.google.com/site/clgdouzy/';">Site internet du collège</button>
			<br>
				<button class="cyan" onclick="window.location.href='mailto:antoine.gandelin@gmail.com';">Aide - Contact</button>
			</div>
			<div id="p3">
				Choisissez une ou plusieurs actions ci-dessous :
			</div>
            <ul>
				<li><button class="yellow" onclick="window.location.href='ajout_eleve.php';">Ajouter un élève (Nom, prénom et classe)</button></li>
				<br>
				<li><button class="yellow" onclick="window.location.href='ajout_horaire.php';">Ajouter un horaire (Date et heure de cours)</button></li>
				<br>
				<li><button class="yellow" onclick="window.location.href='affectation_eleve.php';">Noter la présence d'un élève au CDI</button></li>
			</ul>
		</main>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<footer>
			<div id="copyright">
				© Antoine GANDELIN - Tous droits réservés - 2021
			</div>
		</footer>
	</body>
</html>