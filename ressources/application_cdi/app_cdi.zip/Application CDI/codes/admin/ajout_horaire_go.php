<?php
	$date = $_GET['date'];
	$heure = $_GET['heure'];
	$conn = pg_connect('host=127.0.0.1 dbname=cdi user=cdi_admin password=admin');	
	$chaine_req = 'insert into horaire (id_horaire, date, heure) values ((select count(id_horaire) from horaire), '."'".$date."', '".$heure."')"; 
	$req = pg_query($chaine_req);
	pg_close($conn);
	if($req)
		{
		echo 'L\'horaire a bien été ajouté.';
		}
	else 
		{
		echo 'Erreur : L\'horaire n\'a pas été ajouté';
		}
	echo '<br /><a href="ajout_horaire.php">Revenir à la page d\'ajout d\'un horaire.</a>';
	echo '<br /><a href="accueil_admin.php">Revenir à la page d\'accueil.</a>';
?>