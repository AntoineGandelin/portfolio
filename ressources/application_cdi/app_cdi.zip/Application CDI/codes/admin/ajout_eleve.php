<!DOCTYPE html>
<html>
	<head>
		<title>Application - CDI</title>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8">
		<meta http-equiv="content-style-type" content="text/css">
		<link href="ajout_eleve.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<header>
			<h1>Application - CDI : Ajouter un élève</h1>
		</header>
		<main>
		<div id="p2">
		Pour ajouter un élève, veuillez remplir les informations ci-dessous :
		</div>
		<br>
			<form action="ajout_eleve_go.php" method="get">
				<table id="table">
					<tr><td class="droite">Nom de l'élève :</td><td><input type="text" name="nom" required></td></tr>
					<tr><td class="droite">Prénom de l'élève :</td><td><input type="text" name="prenom" required></td></tr>
					<tr><td class="droite">Classe de l'élève :</td><td><input type="text" name="classe" required></td></tr>
					<tr><td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp ➔</td><td><input type="submit" value="Ajouter l'élève"></td></tr>
					<tr><td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp ➔</td><td><input type="reset" value="Réinitialiser"></td></tr>
				</table>
			</form>
			<br>
			<div id="bouton">
				<button class="cyan" onclick="window.location.href='accueil_admin.php';">Retourner à la page d'accueil</button>
			</div>
		</main>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<footer>
			<div id="copyright">
				© Antoine GANDELIN - Tous droits réservés - 2021
			</div>
		</footer>
	</body>
</html>