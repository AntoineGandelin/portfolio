<!DOCTYPE html>
<html lang="fr">
	<head>
		<title>Electro Vote</title>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<link href="resultat.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="accueil.js"></script>
		<?php 			
			$conn = pg_connect('host=127.0.0.1 dbname=vote user=vote_admin password=admin');	
			$id = (int)$_GET['id'];
			$chaine_req = 'select * from vote where id_vote='.$id;
			$req1 = pg_query($chaine_req);
			$ligne = pg_fetch_assoc($req1);
			$d_deb = new DateTime($ligne['date_debut']);
			$d_fin = new DateTime($ligne['date_fin']);
			$d_cr = new DateTime($ligne['date_creation']);
			pg_close($conn);
		?>	
	</head>
	<body>
		<header>
			<h1>ELECTROVOTE : Prochain vote</h1>
		</header>
		<main>
			<br>
			<article class="titre">
				Titre : <?php echo $ligne['titre'] ?>  
			</article>
			<article class="description">
				Description : <?php echo $ligne['description'] ?>			
			</article>
			<article class="description">
				Date de création : <?php echo $d_cr->format('d/m/Y') ?>			
			</article>
			<article class="description">
				Ouvert à partir du <?php echo $d_deb->format('d/m/Y') ?>			
			</article>
			<article class="description">
				Fermé le <?php echo $d_fin->format('d/m/Y') ?>			
			</article>
		</main>
	</body>
</html>
