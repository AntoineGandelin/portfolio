<!DOCTYPE html>
<html lang="fr">
	<head>
		<title>Electro Vote</title>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<link href="accueil.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="accueil.js"></script>
	</head>
	<body>
		<header>
			<h1>ELECTROVOTE : Votes</h1>
		</header>
		<main>
			<br>
			En vert les votes en cours, en rouge les votes terminés, en bleu les votes à venir 
			<?php
				$conn = pg_connect('host=127.0.0.1 dbname=vote user=vote_admin password=admin');	
				$chaine_req = 'select * from vote order by date_debut desc';
				$req = pg_query($chaine_req);
				$ligne = pg_fetch_assoc($req);
				while($ligne) 
					{
					$d_deb = new DateTime($ligne['date_debut']);
					$d_fin = new DateTime($ligne['date_fin']);
					$d_jour = new DateTime('now');
					$class = $d_fin<$d_jour?'fini':($d_deb>$d_jour?'prevu':'encours');
					$page = $d_fin<$d_jour?'resultat':($d_deb>$d_jour?'consult':'vote');
					echo '<article class="'.$class.'" onclick=ouvrir("'.$page.'.php?id='.$ligne['id_vote'].'") >'.$ligne['titre'];
					echo '<br /><span class="small">Début : ';
					echo $d_deb->format('d/m/Y').', Fin : '; 
					echo $d_fin->format('d/m/Y').'<br/></article>';
					$ligne = pg_fetch_assoc($req);
					}
				pg_close($conn);
			?>			
		</main>
	</body>
</html>