function ouvrir(url)
	{
	window.open(url, 'TOP', 'top=100, left=100, width=940, height=1000, modal=yes');
	}