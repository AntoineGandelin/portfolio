<?php
	session_start();
	$conn = pg_connect('host=127.0.0.1 dbname=vote user=vote_admin password=admin');	
	$login = pg_escape_literal($conn, $_GET['login']);
	$pass = pg_escape_literal(md5($_GET['mdp']));
	$chaine_req = 'select count(id_user) from utilisateur where login='.$login.' and mdp='.$pass;
	$req = pg_query($chaine_req);
	$res = (int)pg_fetch_row($req)[0]; 
	pg_close($conn);
		
	if($res)
		{
		$_SESSION['login'] = $_GET['login'];
		echo 'Bienvenue '.$_SESSION['login'].'. Vous pouvez maintenant participer aux votes qui vous sont attribués.';
		echo '<br /><a href="vote.php?id='.$_GET['id'].'">Revenir à la page de vote.</a>';
		}
	else 
		{
		echo 'Vous n\'êtes pas autorisé à participer aux votes. ';
		echo '<button onclick="window.close()">Fermer cette page</button> ';
		}
	?>	
