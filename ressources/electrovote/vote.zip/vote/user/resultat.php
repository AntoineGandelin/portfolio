<!DOCTYPE html>
<html lang="fr">
	<head>
		<title>Electro Vote</title>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<link href="resultat.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="accueil.js"></script>
		<?php 			
			$conn = pg_connect('host=127.0.0.1 dbname=vote user=vote_admin password=admin');	
			$id = (int)$_GET['id'];
			$chaine_req = 'select * from vote where id_vote='.$id;
			$req1 = pg_query($chaine_req);
			$ligne = pg_fetch_assoc($req1);
			$chaine_req = 'select participation.id_vote, libelle, count(*) from participation join choix using(id_choix) where participation.id_vote='.$id.' group by 1,2 order by 3 desc';
			$req2 = pg_query($chaine_req);
			$tab = pg_fetch_all($req2);
			pg_close($conn);
		?>	
	</head>
	<body>
		<header>
			<h1>ELECTROVOTE : Résultats</h1>
		</header>
		<main>
			<br>
			<article class="titre">
				Titre : <?php echo $ligne['titre'] ?>  
			</article>
			<article class="description">
				Description : <?php echo $ligne['description'] ?>			
			</article>
			<?php
				foreach ($tab as $choix)
					{
					echo '<article class="choix">';
					echo $choix['libelle'].' : '.$choix['count'].' voix.';				
					echo '</article>';
					}			
			?>			
		</main>
	</body>
</html>
