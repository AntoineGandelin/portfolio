<?php
	// Déterminer les points faibles liés à cette page :
	// erreurs envisageables, possibilités de fraude, failles de sécurité, etc
	// Proposer une correction pour chaque point trouvé
	// =================================================
	// Pour chaque point rencontré, procéder par étapes
	// - description du problème
	// - solution envisagée (textuelle)
	// - solution envisagée (code)
	// Remarque : ne vous lancez dans le code qu'une fois 
	// l'ensemble des points faibles repérés
	// =================================================
	
	$conn = pg_connect('host=127.0.0.1 dbname=vote user=vote_admin password=admin');	
	$login = $_GET['log'];
	$id_vote = $_GET['id'];
	$choix = $_GET['ch'];
	$chaine_req = "select id_user from utilisateur where login='".$login."'";
	$req = pg_query($chaine_req);
	$res = pg_fetch_row($req);
	$id_user = $res[0];
	$chaine_req = 'update participation set id_choix='.$choix.' where id_user='.$id_user.' and id_vote='.$id_vote;
	pg_query($chaine_req);
	pg_close($conn);
	header('Location: vote.php?id='.$id_vote);
?>	
