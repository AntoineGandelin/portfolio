<?php
	function generer_cle() 
		{
		$chaine = '!!@@##**2233445566778899aaaaaaaabbccddeeeeeeeeefghiiiiijkmmnnooooooppqrrrrsssttwxyzAAAAAAAABBCCDDEEEEEEEEEFGHJKLMMNNPPQRRRRSSSTTWXYZ';
		//echo strlen($chaine);
		$cle=$chaine[rand(0,132)].$chaine[rand(0,132)].$chaine[rand(0,132)].$chaine[rand(0,132)].$chaine[rand(0,132)].$chaine[rand(0,132)];
		return $cle;
		}

	$num_vote = $_GET['vo']*1; 	
	$tab_aff = $_GET['ok'];
	$cle = generer_cle();

	$conn = pg_connect('host=127.0.0.1 dbname=vote user=vote_admin password=admin');	
	// suppression de toutes les affectations concernant le vote donné	
	pg_query('begin');	
	$chaine_req = 'delete from participation where id_vote = '.$num_vote; 
	pg_query($chaine_req);
	// ajout des participations passées en paramètres
	$chaine_req = 'insert into participation(id_vote, id_user, cle) values ';
	foreach ($tab_aff as $aff)
		{
		$chaine_req = 	$chaine_req.'('.$num_vote.', '.$aff.", '".$cle."'),";  		
		}	
	$chaine_req = substr($chaine_req, 0, strlen($chaine_req)-1);
	pg_query($chaine_req);
	$req = pg_query('commit');
	pg_close($conn);
	if($req)
		{
		echo 'Enregistrement effectué.';
		}
	else 
		{
		echo 'Enregistrement échoué';
		}
	echo '<br /><a href="affectation_vote.php">Revenir à la page d\'affectation des utilisateurs.</a>';
	echo '<br /><a href="accueil.php">Revenir à la page d\'accueil.</a>';
?>


