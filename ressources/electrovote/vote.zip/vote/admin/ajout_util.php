<!DOCTYPE html>
<html>
	<head>
		<title>Electro Vote</title>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8">
		<meta http-equiv="content-style-type" content="text/css">
		<link href="ajout_util.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<header>
			<h1>ELECTROVOTE : Admin : nouvel utilisateur</h1>
		</header>
		<main>
			<form action="ajout_util_go.php" method="get">
				<table>
					<tr><td class="droite">Login</td><td><input type="text" name="lo" length="100"></td></tr>
					<tr class="yellow"><td class="droite">Mot de passe</td><td><input type="text" name="mp"></td></tr>
					<tr><td></td><td><input type="submit" value="Enregistrer"></td></tr>
				</table>
			</form>
		</main>
	</body>
</html>