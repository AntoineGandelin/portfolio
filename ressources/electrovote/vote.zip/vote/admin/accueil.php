<!DOCTYPE html>
<html>
	<head>
		<title>Electro Vote</title>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8">
		<meta http-equiv="content-style-type" content="text/css">
		<link href="accueil.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<header>
			<h1>ELECTROVOTE : Admin : accueil</h1>
		</header>
		<main>
			<ul>
				<li><a href="ajout_util.php">Ajouter un utilisateur</a></li>
				<li><a href="ajout_vote.php">Ajouter un vote</a></li>
				<li><a href="affectation_vote.php">Affecter des utilisateurs à un vote</a></li>
			</ul>			
		</main>
	</body>
</html>