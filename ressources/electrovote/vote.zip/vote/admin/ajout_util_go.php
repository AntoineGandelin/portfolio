<?php
	// protection des valeurs
	$login = substr($_GET['lo'], 0, 10);
	$pass = md5($_GET['mp']);
	
	$conn = pg_connect('host=127.0.0.1 dbname=vote user=vote_admin password=admin');	
	// Cybersécurité - attention, une injection SQL dans le cadre d'une construction de chaîne est toujours possible
	$chaine_req = 'insert into utilisateur (id_user, login, mdp) values ((select max(id_user)+1 from utilisateur), '."'".$login."', '".$pass."')"; 
	$req = pg_query($chaine_req);
	pg_close($conn);
	if($req)
		{
		echo 'Enregistrement effectué.';
		}
	else 
		{
		echo 'Enregistrement échoué';
		}
	echo '<br /><a href="ajout_util.php">Revenir à la page d\'ajout d\'un utilisateur.</a>';
	echo '<br /><a href="accueil.php">Revenir à la page d\'accueil.</a>';
?>


