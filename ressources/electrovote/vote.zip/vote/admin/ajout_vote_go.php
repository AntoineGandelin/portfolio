<?php
	// récupération des deux valeurs d'identifiant
	// de vote et choix (nous partons du principe
	// qu'une seule session est ouverte à la fois)
	$conn = pg_connect('host=127.0.0.1 dbname=vote user=vote_admin password=admin');	

	// vote	
	// gestion des erreurs : vérifier que les champs sont bien remplis
	$chaine_req = 'select max(id_vote) from vote'; 
	$req = pg_query($chaine_req);
	$tab = pg_fetch_row($req);
	// dans $tab[0] il y aura la valeur maxi de l'id_vote
	// ou false

	if($tab[0])
		{
		$id_vote = $tab[0]+1;	
		}
	else 
		{
		$id_vote = 1;
		}
		
	// choix	
	$chaine_req = 'select max(id_choix) from choix'; 
	$req = pg_query($chaine_req);
	$tab = pg_fetch_row($req);

	if($tab[0])
		{
		$id_choix = $tab[0]+1;	
		}
	else 
		{
		$id_choix = 1;
		}

	// date de création
	$objet_date = new DateTime();
	$date_creation = pg_escape_literal($objet_date->format('Y-m-d'));

	// titre
	$titre = pg_escape_literal($_GET['ti']);
	$description = pg_escape_literal($_GET['de']);
	$date_fin = pg_escape_literal($_GET['df']);
	$date_debut = pg_escape_literal($_GET['dd']);

	// Insertion des valeurs dans la table vote
	pg_query('begin');
	$chaine_req = 'insert into vote( id_vote, titre, description, date_creation, date_debut, date_fin) values (';
	$chaine_req = $chaine_req.$id_vote.', '.$titre.', ';
	$chaine_req = $chaine_req.$description.', '.$date_creation.', ';
	$chaine_req = $chaine_req.$date_debut.', '.$date_fin.')';
	pg_query($chaine_req); 
	
	// Choix possibles	
	// Gestion des erreurs : vérifier la présence d'au moins un choix
	// Insertion des valeurs dans la table choix
	$chaine_req = 'insert into choix( id_choix, libelle, id_vote) values ';
	
	for($i=0; $i<8; $i++)
		{
		if($libelle = $_GET['ch'][$i])
			{
			$libelle = pg_escape_literal($libelle);
			$chaine_req = $chaine_req.'('.$id_choix++.', '.$libelle;
			$chaine_req = $chaine_req.', '.$id_vote.'),';
			}	
		}

	$chaine_req = substr($chaine_req, 0, strlen($chaine_req)-1);
	pg_query($chaine_req); 

	$req = pg_query('commit');
	if($req)
		{
		echo 'Insertion réussie dans la table vote.';
		}
	else 
		{
		echo 'Problème lors de l\'insertion.';
		}

	echo '<br /><a href="ajout_vote.php">Revenir à la page d\'ajout d\'un vote.</a>';
	echo '<br /><a href="accueil.php">Revenir à la page d\'accueil.</a>';


		
	pg_close($conn);
?>
