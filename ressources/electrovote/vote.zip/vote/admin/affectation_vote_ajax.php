	<div id="vote">
		<?php
			$conn = pg_connect('host=127.0.0.1 dbname=vote user=vote_admin password=admin');
			// valeur numérique	
			$vote_courant = $_GET['id']*1;	
			$chaine_req = 'select * from vote where id_vote = '.$vote_courant;
			$req = pg_query($chaine_req);
			$ligne = pg_fetch_assoc($req);
			echo 	'<h2>'.$ligne['titre'].'</h2>';
			echo 	$ligne['description'].'<br><br>';
		?>			
		<form action="affectation_vote_ajax_go.php" method="get">
			<input type="hidden" name="vo" value=
			<?php echo '"'.$vote_courant.'"'; ?>
			>
			<table>
				<tr><th width="80%">Nom d'utilisateur</th><th>Vote</th></tr>
				<?php
				// Récupération les utilisateurs et participation  
				$string_req = 'select u.id_user, login, id_vote from utilisateur u inner join participation p on u.id_user = p.id_user where id_vote = ';
				$string_req = $string_req.$vote_courant.'union select id_user, login, 0 from utilisateur where id_user not in ';
				$string_req = $string_req.'(select u.id_user from utilisateur u inner join participation p on u.id_user = p.id_user where id_vote = ';
				$string_req = $string_req.$vote_courant.') order by 3 desc, 2 asc';
				$req = pg_query($string_req);
				$tab = pg_fetch_assoc($req);
				$pair=0;
				while($tab) 
					{
					echo '<tr ';
					if($pair++%2) 
						{
						echo 'class="yellow" ';
						}
					echo '>';
					echo '<td>'.$tab['login'].'</td><td><input type="checkbox" name="ok[]" value="'.$tab['id_user'].'" ';
					if($tab['id_vote'] != 0) 
						{
						echo 'checked';				
						}
					echo '></td><tr>';
					$tab = pg_fetch_assoc($req);
					}
				pg_close($conn);
				?>
				<tr><td><input type="submit" value="Enregistrer"></td><td></td></tr>
			</table>
		</form>	
	</div>		


