<!DOCTYPE html>
<html>
	<head>
		<title>Electro Vote</title>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8">
		<meta http-equiv="content-style-type" content="text/css">
		<script type="text/javascript" src="affectation_vote.js"></script>
		<link href="affectation_vote.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<header>
			<h1>ELECTROVOTE : Admin : affectation vote</h1>
		</header>
		<main>
			<select onchange="ajax_affect()">
				<option value="">--- Sélectionner un vote ---</option>
				<?php
					$conn = pg_connect('host=127.0.0.1 dbname=vote user=vote_admin password=admin');	
					$chaine_req = 'select * from vote order by date_debut desc';
					$req = pg_query($chaine_req);
					$ligne = pg_fetch_assoc($req);
					while($ligne) 
						{
						echo '<option value="'.$ligne['id_vote'].'">';
						echo $ligne['titre'];	
						echo '</option>';
						$ligne = pg_fetch_assoc($req);
						}
					pg_close($conn);
				?>
			</select>
			<br><br>
			<div id="affect">
			
			</div>

		</main>
	</body>
</html>