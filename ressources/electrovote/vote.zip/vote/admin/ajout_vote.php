<!DOCTYPE html>
<html>
	<head>
		<title>Electro Vote</title>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8">
		<meta http-equiv="content-style-type" content="text/css">
		<link href="ajout_vote.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<header>
			<h1>ELECTROVOTE : Admin : nouveau vote</h1>
		</header>
		<main>
			<form action="ajout_vote_go.php" method="get">
				<table>
					<tr><td class="droite">Titre</td><td><input type="text" name="ti" length="100"></td></tr>
					<tr class="yellow"><td class="droite">Description</td><td><textarea name="de"></textarea></td></tr>
					<tr><td class="droite">Date de début</td><td><input type="date" name="dd"></td></tr>
					<tr class="yellow"><td class="droite">Date de fin</td><td><input type="date" name="df"></td></tr>
					<tr><td class="droite">Choix 1</td><td><input type="text" name="ch[]" length="150"></td></tr>
					<tr class="yellow"><td class="droite">Choix 2</td><td><input type="text" name="ch[]" length="150"></td></tr>
					<tr><td class="droite">Choix 3</td><td><input type="text" name="ch[]" length="150"></td></tr>
					<tr class="yellow"><td class="droite">Choix 4</td><td><input type="text" name="ch[]" length="150"></td></tr>
					<tr><td class="droite">Choix 5</td><td><input type="text" name="ch[]" length="150"></td></tr>
					<tr class="yellow"><td class="droite">Choix 6</td><td><input type="text" name="ch[]" length="150"></td></tr>
					<tr><td class="droite">Choix 7</td><td><input type="text" name="ch[]" length="150"></td></tr>
					<tr class="yellow"><td class="droite">Choix 8</td><td><input type="text" name="ch[]" length="150"></td></tr>
					<tr><td></td><td><input type="submit" value="Enregistrer"></td></tr>
				</table>
			</form>
		</main>
	</body>
</html>