// Programme permettant de transformer
// un fichier à champ fixe
// en csv (seuls certains champs sont conservés)

#include <iostream>
#include <fstream>
#include <string>

struct sortie
	{
	std::string nom; 
	std::string prenom; 
	char sexe;
	std::string date_nais; 
	std::string code_com_nais; 
	std::string code_pays_nais; 
	std::string date_dc; 
	std::string code_com_dc; 
	std::string code_pays_dc; 
	};

struct entree
	{
	char nom[81];
	char sexe;
	char date_nais[9];
	char code_lieu_nais[6];
	char commune_nais[31];
	char pays_nais[31];
	char date_dc[9];
	char code_lieu_dc[6];
	char acte[10];
	char filler[24];
	};

bool lire_ligne(entree &ent, std::fstream &f)
	{
	bool b=true;
	f.read((char *)&ent.nom,80);
	if(!f.good())
		{
		b=false;		
		}
	f.read(&ent.sexe,1);
	f.read((char *)&ent.date_nais,8);
	f.read((char *)&ent.code_lieu_nais,5);
	f.read((char *)&ent.commune_nais,30);
	f.read((char *)&ent.pays_nais,30);
	f.read((char *)&ent.date_dc,8);
	f.read((char *)&ent.code_lieu_dc,5);
	f.read((char *)&ent.acte,9);
	f.read((char *)&ent.filler,24);	
	return b;
	}

std::string transfo_date(std::string s1)
	{
	std::string s2;
	s2 = s1.substr(0,4);
	s2 += "-";
	s2 += s1.substr(4,2);
	s2 += "-";
	s2 += s1.substr(6,2);
	
	return s2;	
	}


int main(int a, char**b) 
	{
	// Création d'une variable de type de structure entree
	entree e;
	sortie s;
	e.nom[80]=e.date_nais[8]=e.code_lieu_nais[5]=e.commune_nais[30]=e.pays_nais[30]=e.date_dc[8]=e.code_lieu_dc[5]=e.acte[9]=0;
	// Ouverture des fichiers 
	std::fstream entree;
	entree.open(b[1], std::ios::in|std::ios::binary);	
	// Parcours du fichier d'entrée 
	while(lire_ligne(e, entree))
		{
		// TRAITEMENT DES DONNEES
		// 1 - valoriser s.nom et s.prenom
		// à partir de e.nom 	
		s.nom = e.nom;
		s.prenom = e.nom;
		size_t poset = s.nom.find('*');
		size_t possl = s.nom.find('/');
		s.nom = s.nom.substr(0, poset);
		poset++;
		s.prenom = s.prenom.substr(poset, possl-poset);
		std::cout<<"==================\n";
		std::cout<<s.nom<<"#\n";	
		std::cout<<s.prenom<<"#\n";	
		// 2 - s.sexe
		s.sexe = e.sexe;
		std::cout<<s.sexe<<"#\n";	
		// 3 - s.date_nais
		s.date_nais = transfo_date(e.date_nais);
		std::cout<<s.date_nais<<"#\n";	
		}
		
	// Fermeture des fichiers
	entree.close();
	// Fin du programme
	std::cout<<"Lecture terminée !\n";
	}
	