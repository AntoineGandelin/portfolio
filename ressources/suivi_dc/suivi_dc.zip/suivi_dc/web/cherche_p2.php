<!DOCTYPE html>
<html>
	<head>
		<title>Recherche DC</title>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8">
		<meta http-equiv="content-style-type" content="text/css">
		<meta http-equiv="expires" content="0">
		<link href="cherche.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="cherche.js"></script>
	</head>
	<body>
		<h1>RECHERCHE D'UN DÉCÈS</h1>
		<form action="cherche_p2.php" method="get">
			<input type="text" name="mot" value="">
			<input type="submit" value="?">
		</form>
		<?php
			if(isset($_GET['mot']))
				{
				// Mot à chercher
				$cherche = strtoupper($_GET['mot']);

				echo '<table border="1">';
				echo '<tr>';
					echo '<th>Num</th>';
					echo '<th>Nom</th>';
					echo '<th>Prénom</th>';
					echo '<th>Pays</th>';
				echo '</tr>';
				echo '<br>';
				
				$conn = pg_connect('host=127.0.0.1 dbname=dc user=dc_admin password=admin');
				// Mise en place des paramètres pour la pagination
				if(!isset($_GET['offset']))
					{
					// Chaîne qui contient la requête comptabilisant le nombre de ligne du résultat 					
					$string_req = "select count(*) from dc left join pays on pays.id_pays = dc.id_pays where dc.nom like '%".$cherche."%'";
					// lancement de la requête					
					$req = pg_query($string_req);
					// Récupération de la  première colonne de la première ligne
					$taille = pg_fetch_row($req)[0];
					// Première utilisation de l'offset, celui-ci vaudra 0
					$off=0;
					}
				else 
					{
					// Il y a déjà un offset, on le récupère 
					$off = $_GET['offset'];
					// La taille est passée en paramètre pour éviter de lancer la requête
					// de calcul à chaque apple de la page. 
					$taille = $_GET['taille']; 
					}
				
				$string_req = "select dc.nom, prenom, pays.nom as pays  from dc left join pays on pays.id_pays = dc.id_pays where dc.nom like '%".$cherche."%' order by dc.nom, prenom";
				// On modifie la requête pour tenir compte de l'offset
				$string_req .= ' offset '.$off.' limit 20'; 
				$req = pg_query($string_req);
				$tab = pg_fetch_assoc($req);
				// Pour permettre la numérotation des lignes
				$inc = 1;
				while($tab)
					{
					echo '<tr>';
						echo '<td>'.($off+$inc++).'</td>';
						echo '<td>'.$tab['nom'].'</td>';
						echo '<td>'.$tab['prenom'].'</td>';
						echo '<td>'.$tab['pays'].'</td>';
					echo '</tr>';
					$tab = pg_fetch_assoc($req);
					}
				pg_close($conn);
				echo "</table>\n";
				// Zone de déplacement dans les enregistrements

				// affichage des pages
				for($i=0; $i<=$taille; $i=$i+20)
					{
					$string_page = 'cherche_p2.php?mot='.$cherche.'&offset='.$i.'&taille='.$taille;
					echo '&nbsp;<a href="'.$string_page.'">'.(int)($i/20).'</a>&nbsp;';
					}
				}
		?>
	</body>
</html>