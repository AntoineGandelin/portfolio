<!DOCTYPE html>
<html>
	<head>
		<title>Recherche DC</title>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8">
		<meta http-equiv="content-style-type" content="text/css">
		<meta http-equiv="expires" content="0">
		<link href="cherche.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="cherche.js"></script>
	</head>
	<body>
		<h1>RECHERCHE D'UN DÉCÈS</h1>
		<form action="cherche.php" method="get">
			<input type="text" name="mot">
			<input type="submit" value="?">
		</form>
		<?php
			// On vérifie que l'utilsateur a déjà saisi un mot
			if(isset($_GET['mot']))
				{
				// Affichage de l'entête du tableau résultat			
				echo '<table border="1">';
				echo '<tr>';
					echo '<th>Nom</th>';
					echo '<th>Prénom</th>';
					echo '<th>Pays</th>';
				echo '</tr>';
				
				// connexion à la base
				$conn = pg_connect('host=127.0.0.1 dbname=dc user=dc_admin password=admin');
				
				// construction de la requête (on ne gère pas la sécurité)				
				$cherche = strtoupper($_GET['mot']);
				$string_req = "select dc.nom, prenom, pays.nom as pays from dc left join pays on pays.id_pays = dc.id_pays where dc.nom like '%".$cherche."%' order by dc.nom, prenom";

				// Envoi de la requête au système de gestion de bases de données
				$req = pg_query($string_req);
				
				// Parcours du jeu d'enregistrements résultat de l'envoi de la requête
				$tab = pg_fetch_assoc($req);
				while($tab)
					{
					// traitement de chaque ligne du jeu d'enregistrements
					echo '<tr>';
						echo '<td>'.$tab['nom'].'</td>';
						echo '<td>'.$tab['prenom'].'</td>';
						echo '<td>'.$tab['pays'].'</td>';
					echo '</tr>';
					
					// Lecture de l'enregistrement suivant
					$tab = pg_fetch_assoc($req);
					}
					
				// fermeture de la connexion	
				pg_close($conn);
				echo '</table>';
				}
		?>
	</body>
</html>