<?php
	/*========================================
	            xpfight v. 0.70
	           BTS SIO SLAM 2020
	             F. Pasqualini  
	Partie serveur du programme xpfight dédiée
	à l'enregistrement des meilleurs scores.
	Cette page php va vérifier que les valeurs 
	transmises permettent au joeur de s'inscrire
	dans la base des meilleurs scores. On ne
	conserve que le score des joueurs étant
	dans les 3 premiers pour une grille donnée.
	========================================*/

	// On vérifie qu'un jeton a bien étant transmis en paramètre
	if(isset($_GET['jeton']))
		{
		$jeton = $_GET['jeton'];
		// On vérifie qu'un nom a bien étant transmis en paramètre
		if(isset($_GET['nom']))
			{
			$nom = $_GET['nom'];
			// On vérifie qu'un nom a été saisi par l'utilisateur
			if($nom == '')
				{
				$nom = 'Anonyme';				
				}				
			}	
		else 
			{
			$nom = 'Anonyme';				
			}
		
		// On évite les noms de plus de 20 lettres 
		// Permet une petite protection contre les
		// injections SQL
		$nom = substr($nom, 0, 20);			
 			
		// On lit le fichier contenant les différentes informations
		// concernant le score effectué. Le nom du fichier est 
		// le jeton obtenu pour validation du score
		// On remplit une variable de type tableau associatif 
		$fic = fopen($jeton, 'r'); 
		if($fic) 
			{
			while($s = fgets($fic))
				{
				$temp = explode(':', $s);
				$tab[$temp[0]]=$temp[1];				
				}		
			fclose($fic);
			}
		else 
			{
			echo 'Erreur d\'accès au fichier ou mauvais jeton.';
			}
			
		// On vérifie que le nombre de tués est éligible
		// à une sauvegarde en récupérant le meilleur
		// nombre de tués dans la base
		require_once('connect.php');
		$s_req = 'select max(nb_tues) from score where grille = '.$tab['grille'];
		$req = pg_query($s_req);
		$nb_tues = pg_fetch_row($req)[0];

		// Si le score est équivalent à celui du meilleur score de la base
		// on vérifie qu'il n'y a pas déjà 3 scores dans la base.
		// Si c'est le cas on insère le nouveau score dans la base.
		$insert = false;
		if($tab['nb_tues'] > $nb_tues)
			{
			$insert =true;			
			}		
		else 
			{			
			if($tab['nb_tues'] == $nb_tues)
				{
				$s_req = 'select count(id_score) from score where nb_tues ='.$nb_tues.' and grille = '.$tab['grille'];
				$req = pg_query($s_req);
				$nb_lignes = pg_fetch_row($req)[0];
				if($nb_lignes < 3)
					{
					$insert = true;
					}				
				}
			}		
		
		// On insère dans la base tous les paramètres d'un score plus la date, 
		// l'heure et l'IP de l'ordinateur client 
		if($insert)
			{
			$s_req = 'insert into score(pseudo, date_score, ip, grille, nb_tues, perso1, perso2, perso3, pos1, pos2, pos3) values (';
			$s_req = $s_req.pg_escape_literal($nom).', ';
			$s_req = $s_req."'now'::timestamp, ";
			// Recherche de l'IP
			$ip = $_SERVER['REMOTE_ADDR'];
			$s_req = $s_req.pg_escape_literal($ip).', ';
			$s_req = $s_req.intval($tab['grille']).', ';
			$s_req = $s_req.intval($tab['nb_tues']).", '";
			$perso = array('', 'A', 'M', 'S');
			$s_req = $s_req.$perso[intval($tab['perso1'])]."', '";
			$s_req = $s_req.$perso[intval($tab['perso2'])]."', '";
			$s_req = $s_req.$perso[intval($tab['perso3'])]."', ";
			$s_req = $s_req.intval($tab['pos1']).', ';
			$s_req = $s_req.intval($tab['pos2']).', ';
			$s_req = $s_req.intval($tab['pos3']).')';
			$req = pg_query($s_req);
			}
							
		// Enfin on envoie au client la liste des 3 meilleurs scores
		// pour la grille donnée : nom, nombre de tués, date
		// Le tout sous forme d'une chaîne XML
		$s_req = 'select pseudo, nb_tues, date_score::date, grille from score where grille = '.$tab['grille'].' order by nb_tues desc, id_score limit 3';
		$req = pg_query($s_req);
		$tab2 = pg_fetch_all($req);
		$r = "\n";
		$t = "\t";
		$xml_s = '<?xml version="1.0" encoding="UTF-8"?>'.$r;
		$xml_s .= '<grille numero='.$tab2[0]['grille'].'>'.$r;
		$taille = count($tab2);
		for($i=0; $i<$taille;$i++)
			{
			$xml_s = $xml_s.$t.'<perso>'.$r;
				$xml_s = $xml_s.$t.$t.'<place>'.($i+1).'</place>'.$r;
				$xml_s = $xml_s.$t.$t.'<pseudo>'.$tab2[$i]['pseudo'].'</pseudo>'.$r;
				$xml_s = $xml_s.$t.$t.'<nb_tues>'.$tab2[$i]['nb_tues'].'</nb_tues>'.$r;
				$xml_s = $xml_s.$t.$t.'<date>'.$tab2[$i]['date_score'].'</date>'.$r;
			$xml_s = $xml_s.$t.'</perso>'.$r;
			}
		$xml_s .= '</grille>'.$r;	

		echo $xml_s;
		
		// On effece le fichier jeton et on ferme la connexion à la base
		pg_close($conn);
		unlink($jeton);
		}
	
?>