/*========================================
            xpfight v. 0.70
           BTS SIO SLAM 2020
             F. Pasqualini  
Partie serveur du programme xpfight. Ce
programme cgi va vérifier que les valeurs 
transmises sont correctes et valider dans
ce cas le résultat par l'envoi d'un jeton
(md5) qui permettra au client de valider
son insertion dans la base de données 
comme joueur étant dans les 3 premiers
meilleurs scores pour une grille donnée.
========================================*/

#include <iostream>
#include <sstream>	
#include <fstream>	
#include <string>
#include <vector>
#include <unistd.h>

// Structure utilisée pour chaque case de la grille
struct cellule
	{
	int val; // type de cellule	
	int pos; // position dans le tableau
	};

// Frappe d'un soldat 
int fsoldat(cellule * c, int centre)
	{
	int nb_tues = 0;
   int lig = centre/10;
   int col = centre %10;
   std::vector <unsigned int> v;
   int p = 0;

   if(lig-1 >= 0 && col-1 >= 0)
   	{
      p = (lig-1)*10+(col-1);
      v.push_back(p);
      }
	if(col-1>=0)
     	{
      p = (lig)*10+(col-1);
      v.push_back(p);
      }
  	if(lig+1<10 && col-1 >= 0)
   	{
      p = (lig+1)*10+(col-1);
      v.push_back(p);
      }
  	if(lig-1 >= 0)
   	{
      p = (lig-1)*10+(col);
      v.push_back(p);
      }
  	if(lig+1<10)
      {
      p = (lig+1)*10+(col);
      v.push_back(p);
      }
  	if(lig-1>=0 && col+1<10)
   	{
      p = (lig-1)*10+(col+1);
      v.push_back(p);
      }
   if(col+1<10)
   	{
      p = (lig)*10+(col+1);
      v.push_back(p);
      }
   if(lig+1<10 && col+1<10)
   	{
      p = (lig+1)*10+(col+1);
      v.push_back(p);
      }
	int taille = v.size();
   for(int i =0; i< taille; i++)
   	{

      if(c[v.at(i)].val == 9)
            {
            c[v.at(i)].val = 10;
            nb_tues++;
            }
        }
	return nb_tues;
	}

// Frappe d'un mage 
int fmage(cellule * c, int centre)
	{
	int nb_tues = 0;
   int lig = centre/10;
   int col = centre %10;
   std::vector <unsigned int> v;
   int p = 0;
	if(lig-2>=0 && col-2 >= 0)
  		{
  		p = (lig-2)*10+(col-2);
 	 	v.push_back(p);
  		}
 	if(lig-1>=0 && col-1 >= 0)
  		{
  		p = (lig-1)*10+(col-1);
  		v.push_back(p);
  		}
 	if(lig+1<10 && col+1 < 10)
  		{
  		p = (lig+1)*10+(col+1);
  		v.push_back(p);
  		}
 	if(lig+2<10 && col+2 < 10)
  		{
  		p = (lig+2)*10+(col+2);
  		v.push_back(p);
  		}
 	if(lig-2>=0 && col+2 < 10)
  		{
  		p = (lig-2)*10+(col+2);
  		v.push_back(p);
  		}
 	if(lig-1>=0 && col+1 < 10)
  		{
  		p = (lig-1)*10+(col+1);
  		v.push_back(p);
  		}
 	if(lig+1<10 && col-1 >=0)
  		{
  		p = (lig+1)*10+(col-1);
  		v.push_back(p);
 		}
 	if(lig+2<10 && col-2 >=0)
  		{
  		p = (lig+2)*10+(col-2);
  		v.push_back(p);
		}
	int taille = v.size();
   for(int i =0; i< taille; i++)
   	{
      if(c[v.at(i)].val == 9)
            {
            c[v.at(i)].val = 10;
            nb_tues++;
            }
        }
	return nb_tues;
	}

// Frappe d'un archer 
int farcher(cellule * c, int centre)
	{
	int nb_tues = 0;
   int lig = centre/10;
   int col = centre %10;
   std::vector <unsigned int> v;
   int p = 0;
   if(lig-3 >= 0)
        {
        p = (lig-3)*10+(col);
        v.push_back(p);
        }
    if(lig-2 >= 0)
        {
        p = (lig-2)*10+(col);
        v.push_back(p);
        }
    if(col-3>=0)
        {
        p = (lig)*10+(col-3);
        v.push_back(p);
        }
    if(col-2>=0)
        {
        p = (lig)*10+(col-2);
        v.push_back(p);
        }
    if(col+3 < 10)
        {
        p = (lig)*10+(col+3);
        v.push_back(p);
        }
    if(col+2<10)
        {
        p = (lig)*10+(col+2);
        v.push_back(p);
        }
    if(lig+3<10)
        {
        p = (lig+3)*10+col;
        v.push_back(p);
        }
    if(lig+2<10)
        {
        p = (lig+2)*10+col;
        v.push_back(p);
        }
	int taille = v.size();
   for(int i =0; i< taille; i++)
   	{
      if(c[v.at(i)].val == 9)
            {
            c[v.at(i)].val = 10;
            nb_tues++;
            }
        }
	return nb_tues;
	}

// Fonction permettant de parser la chaîne de paramètres
std::vector<std::string> split(std::string const & s, char d)
	{
   std::vector<std::string> v;
   std::istringstream flux_chaine(s);
   std::string t;
   while(std::getline(flux_chaine, t, d))
   	{
      v.push_back(t);
    	}
   return v;
	}

// Retourne la valeur d'un paramètre
int valeur(std::string s)
	{
	int i=0;
   std::vector<std::string> v = split(s, '=');
   i = atoi(v.at(1).c_str());
	return i;	
	}


int main(int a, char**b, char** e)
	{
	// Indique que c'est un flux HTML
	std::cout<<"Content-type: text/html\n\n";

	// Recherche du QUERY_STRING
	int i = 0;
	std::string param;
	while(e[i])
		{
		if(e[i][0] == 'Q')
			{
			param = e[i]+13;			
			}		
		i++;
		}
	
	// On récupère la chaîne de paramètres sous
	// la forme d'un vector de string
   std::vector<std::string> v;
	v=split(param,'&');

	// On s'appuie sur l'ordre des paramètres
	// TODO : fonciton à faire évoluer pour pouvoir traiter
	// la chaîne de paramètres quelque soit l'ordre
	int grille = valeur(v.at(0));
	int nb_tues = valeur(v.at(1));
	cellule perso[3];
	perso[0].val = valeur(v.at(2)); 
	perso[0].pos =	valeur(v.at(3));
	perso[1].val = valeur(v.at(4)); 
	perso[1].pos =	valeur(v.at(5));
	perso[2].val = valeur(v.at(6)); 
	perso[2].pos =	valeur(v.at(7));

	// Vérification que les valeurs transmises
	// aboutissent bien au même nombre de tués
	// transmis
	
	// Construction de la grille	
	cellule c[100];
	for(int i=0; i<100; i++)
		{
		c[i].val = 0;
		c[i].pos = i;		
		}

	// Placement des monstres	
   srand(grille);
   int compteur = 0;
   while(compteur<10)
   	{
      unsigned int i = rand()%100;
      if(c[i].val == 0)
      	{
			c[i].val = 9;
         compteur++;
         }
   	}	
	int t = 0;

	// Traitement des cases contenant 
	// les 3 personnages pour obtenir
	// le nombre de tués
	enum perso{archer=1, mage=2, soldat=3};
	for(int i =0; i<3 ;i++)
		{
		t += ((perso[i].val == archer) ?  farcher(c, perso[i].pos) : ((perso[i].val == mage) ? fmage(c, perso[i].pos) : fsoldat(c, perso[i].pos)));
		}
	
	// On vérifie que le nombre de tués
	// est effectivement celui transmis
	// dans ce cas, on envoie un jeton
	// sur le flux de sortie standard 
	// (réponse HTTP d'apache))	
	if(t==nb_tues)
		{

		// Envoyer un jeton
		srand(time(NULL));
		std::string alea = std::to_string(rand());
		std::string jeton = crypt(alea.c_str(),"$3$")+4;
		std::cout<<jeton;

		// Sauvegarde du jeton (qui sera le nom du fichier)
		// et des paramètres transmis
		std::fstream f;
		f.open(jeton.c_str(), std::fstream::out);
		//  vérification d'accès
		f<<"grille:"<<grille<<"\n";
		f<<"nb_tues:"<<nb_tues<<"\n";
		f<<"perso1:"<<perso[0].val<<"\n";
		f<<"pos1:"<<perso[0].pos<<"\n";
		f<<"perso2:"<<perso[1].val<<"\n";
		f<<"pos2:"<<perso[1].pos<<"\n";
		f<<"perso3:"<<perso[2].val<<"\n";
		f<<"pos3:"<<perso[2].pos<<"\n";
		f.close();
		}	
	else
		{
		// Sinon on envoie la valeur 0
		std::cout<<"0";
		}	
	}