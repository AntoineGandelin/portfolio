<?php
		$conn = pg_connect('host=127.0.0.1 dbname=xpfight user=xpfight_admin password=admin');
?>