#include "archer.h"

archer::archer(QString t) : perso()
    {
    theme = t;
    QPixmap pic;
    QString fic_im = "archer.png";
    fic_im = "themes/" + t + "/" + fic_im;
    pic.load(fic_im);
    setPixmap(pic);
    set_val(1);
    }

unsigned int archer::fight(std::array <perso *, 100>& a)
    {
    unsigned int nb_tues = 0;
    unsigned int centre = get_position();
    int lig = centre/10;
    int col = centre %10;
    std::vector <unsigned int> v;
    int p = 0;
    if(lig-3 >= 0)
        {
        p = (lig-3)*10+(col);
        v.push_back(p);
        }
    if(lig-2 >= 0)
        {
        p = (lig-2)*10+(col);
        v.push_back(p);
        }
    if(col-3>=0)
        {
        p = (lig)*10+(col-3);
        v.push_back(p);
        }
    if(col-2>=0)
        {
        p = (lig)*10+(col-2);
        v.push_back(p);
        }
    if(col+3 < 10)
        {
        p = (lig)*10+(col+3);
        v.push_back(p);
        }
    if(col+2<10)
        {
        p = (lig)*10+(col+2);
        v.push_back(p);
        }
    if(lig+3<10)
        {
        p = (lig+3)*10+col;
        v.push_back(p);
        }
    if(lig+2<10)
        {
        p = (lig+2)*10+col;
        v.push_back(p);
        }
    int taille = v.size();
    QString fic_im = "monstre_mort.png";
    fic_im = "themes/" + theme + "/" + fic_im;
    QPixmap pic(fic_im);
    for(int i =0; i< taille; i++)
        {
        if(a.at(v.at(i))->get_val() == 9)
            {
            a.at(v.at(i))->set_val(10);
            a.at(v.at(i))->setPixmap(pic);
            nb_tues++;
            }
        }
    return nb_tues;
    }

