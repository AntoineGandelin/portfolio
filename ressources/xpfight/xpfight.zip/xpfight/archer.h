#ifndef ARCHER_H
#define ARCHER_H

#include "perso.h"

class archer : public perso
    {
    private:
        QString theme;

    public:
        archer(QString ="classique");
        unsigned int fight(std::array <perso *, 100>&);
    };

#endif // ARCHER_H
