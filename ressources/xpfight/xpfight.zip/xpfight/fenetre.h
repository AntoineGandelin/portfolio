#ifndef FENETRE_H
#define FENETRE_H

#include <QMainWindow>
#include <QLabel>
#include <QMessageBox>
#include <array>
#include "ui_fenetre.h"

#include "perso.h"
#include "neutre.h"
#include "monstre.h"
#include "archer.h"
#include "soldat.h"
#include "mage.h"
#include "aide.h"

QT_BEGIN_NAMESPACE
    namespace Ui
        {
        class fenetre;
        }
QT_END_NAMESPACE

class fenetre : public QMainWindow
    {
    Q_OBJECT

    public:
        fenetre(QWidget *parent = nullptr);
        ~fenetre();

    private:
        Ui::fenetre *ui;
        std::array <perso*, 100> per;
        std::string jeton;
        QString url;
        QString theme;

    private slots:
        void init();
        void change(int);
        void resultat();
        void envoi();
        void save();
        // menu
        void quitter();
        void aide();
        void a_propos();
        void changer_theme();
    };
#endif // FENETRE_H
