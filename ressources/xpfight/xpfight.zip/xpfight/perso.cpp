#include "perso.h"
#include <iostream>

perso::perso() : QLabel()
    {
    setFixedSize(40,40);
    val = 0;
    pos = 0;
    }

void perso::set_position(unsigned int i)
    {
    pos = i<1000?i:0;
    }

void perso::set_val(unsigned int i)
    {
    val = i<100?i:0;
    }

void perso::mousePressEvent(QMouseEvent * e)
    {
    if (e->button() == Qt::LeftButton)
        {
        emit clicked(pos);
        }
    }

perso::~perso()
    {

    }

unsigned int perso::get_val()
    {
    return val;
    }

unsigned int perso::get_position()
    {
    return pos;
    }
