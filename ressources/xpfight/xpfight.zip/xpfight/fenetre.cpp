#include "fenetre.h"
#include "ui_fenetre.h"
#include <sstream>
#include <iostream>

// Réseau
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkRequest>
#include <QtNetwork/QNetworkReply>
#include <QUrl>
#include <QEventLoop>

// Autre
#include <QXmlStreamReader>
#include <QDialog>
#include <QFile>
#include <QDir>

void fenetre::init()
    {
    // Visibilité de l'envoi du score
    // Changement des boutons
    ui->b_envoi->setVisible(false);
    ui->b_enregistrer->setVisible(false);
    ui->t_nom->setVisible(false);
    ui->t_nom->clear();
    ui->b_fight->setVisible(true);
    ui->b_envoi->setVisible(false);
    connect(ui->b_envoi, SIGNAL(clicked()), this, SLOT(envoi()));
    connect(ui->b_enregistrer, SIGNAL(clicked()), this, SLOT(save()));
    // Mise à jour du array
    for(int i=0; i<100; i++)
        {
        neutre * n;
        n = new neutre(theme);
        per.at(i)=n;
        per.at(i)->set_position(i);
        connect(per.at(i), SIGNAL(clicked(int)), this, SLOT(change(int)));
        // Mise en place de la grille
        ui->la_grille->addWidget(per.at(i), i/10, i%10);
        }
    // Distribution des monstres
    int graine;
    graine = ui->t_numero->text().toInt();
    srand(graine);
    int compteur = 0;
    while(compteur<10)
        {
        unsigned int i = rand()%100;
        if(per.at(i)->get_val() == 0)
            {
            monstre * m;
            m = new monstre(theme);
            m->set_position(i);
            per.at(i) = m;
            ui->la_grille->addWidget(per.at(i), i/10, i%10);
            compteur++;
            }
        }
    }

fenetre::fenetre(QWidget *parent) : QMainWindow(parent), ui(new Ui::fenetre)
    {
    ui->setupUi(this);

    //TRAVAIL A FAIRE
    srand(time(nullptr));
    int gr = rand()%100+1;
    QString st;
    st.setNum(gr);
    ui->t_numero->setText(st);

    // MENU
    QMenu * menu = new QMenu("XPFight", this);

    QAction * about = new QAction("A &Propos",this);
    connect(about, SIGNAL(triggered()),this, SLOT(a_propos()));
    menu->addAction(about);

    QAction * aide = new QAction("&Aide",this);
    connect(aide, SIGNAL(triggered()),this, SLOT(aide()));
    menu->addAction(aide);

    //separateur
    menu->addSeparator();

    QAction * quit = new QAction("&Quitter",this);
    connect(quit, SIGNAL(triggered()),this, SLOT(quitter()));
    menu->addAction(quit);


    //Ajout du Menu à la barre de menu
    ui->barre_menu->addMenu(menu);

    // Mise à jour de l'URL du serveur
    QFile fic("xpfight.ini");
    fic.open(QIODevice::ReadOnly | QIODevice::Text);
    url = fic.readLine();
    url.remove(url.size()-1,url.size());
    url.remove(0,4);
    // Emplacement des thèmes - récupération du thème par défaut
    theme = fic.readLine();
    theme.remove(theme.size()-1,theme.size());
    theme.remove(0,6);
    fic.close();

    // Construction du menu "Thème"
    QMenu * menut = new QMenu("Thème", this);
    QDir d_theme("themes");
    d_theme.setFilter(QDir::NoDotAndDotDot|QDir::Dirs);
    QStringList l = d_theme.entryList();
    int taille = l.size();
    for(int i = 0; i<taille; i++)
        {
        QAction * q = new QAction;
        q->setText(l.at(i));
        connect(q, SIGNAL(triggered()),this, SLOT(changer_theme()));
        menut->addAction(q);
        }
    ui->barre_menu->addMenu(menut);
    init();
    connect(ui->b_init, SIGNAL(clicked()), this, SLOT(init()));
    connect(ui->b_fight, SIGNAL(clicked()), this, SLOT(resultat()));
    }

fenetre::~fenetre()
    {
    delete ui;
    }

void fenetre::change(int pos)
    {
    if(per.at(pos)->get_val() ==  0)
        {
        archer * a;
        a = new archer(theme);
        a->set_position(pos);
        connect(a, SIGNAL(clicked(int)), this, SLOT(change(int)));
        per.at(pos) = a;
        ui->la_grille->addWidget(per.at(pos), pos/10, pos%10);
        }
    else
        {
        if(per.at(pos)->get_val() == 1)
            {
            mage * m;
            m = new mage(theme);
            m->set_position(pos);
            connect(m, SIGNAL(clicked(int)), this, SLOT(change(int)));
            per.at(pos) = m;
            ui->la_grille->addWidget(per.at(pos), pos/10, pos%10);
            }
        else
            {
            if(per.at(pos)->get_val() == 2)
                {
                soldat * s;
                s = new soldat(theme);
                s->set_position(pos);
                connect(s, SIGNAL(clicked(int)), this, SLOT(change(int)));
                per.at(pos) = s;
                ui->la_grille->addWidget(per.at(pos), pos/10, pos%10);
                }
            else
                {
                neutre * n;
                n = new neutre(theme);
                n->set_position(pos);
                connect(n, SIGNAL(clicked(int)), this, SLOT(change(int)));
                per.at(pos) = n;
                ui->la_grille->addWidget(per.at(pos), pos/10, pos%10);
                }
            }
        }
    }

void fenetre::resultat()
    {
    // Vérification de la conformité de la grille
    unsigned int nb_monstres = 0;
    unsigned int nb_persos = 0;
    unsigned int type = 0;
    for(int i=0; i<100; i++)
        {
        type = per.at(i)->get_val();
        if(type)
            {
            if (type == 9)
                {
                nb_monstres++;
                }
                else
                {
                nb_persos++;
                }
            }
        }
    if(nb_monstres == 10 && nb_persos == 3)
        {
        int res = 0;
        for(int i=0; i<100; i++)
            {
            // Appel de toutes les fonctions fight des persos
            res += per.at(i)->fight(per);
            }
        // Changement des boutons
        ui->b_fight->setVisible(false);
        ui->b_envoi->setVisible(true);
        }
    else
        {
        QMessageBox mess(QMessageBox::Warning, "ATTENTION", "Pour que le fight soit valide, vous devez placer 3 personnages, pas un de plus ni de moins.");
        mess.exec();
        }
    }

void fenetre::envoi()
    {
    // Réseau
    QEventLoop eventLoop;
    QNetworkAccessManager manager;
    connect(&manager, SIGNAL(finished(QNetworkReply*)), &eventLoop, SLOT(quit()));

    // Construction de la requête http

    //DEBUG
    std::cerr<<"#"<<url.toStdString()<<"#";

    QString adresse = url;
    adresse += "xpfight_server.cgi?";
    // Récupération des paramètres dans la grille
    std::ostringstream o;
    o<<"grille="<<ui->t_numero->text().toStdString();
    int nb = 0;
    for(int i=0; i<100; i++)
        {
        if(per.at(i)->get_val() == 10)
            {
            nb++;
            }
        }
    o<<"&nb_tues="<<nb;
    for(int i=0; i<100; i++)
        {
        if(per.at(i)->get_val() == 1 || per.at(i)->get_val() == 2 || per.at(i)->get_val() == 3)
            {
            // On récupère les valeurs
            o<<"&perso="<<per.at(i)->get_val();
            o<<"&pos="<<per.at(i)->get_position();
            }
        }
    adresse += o.str().c_str();
    //DEBUG
    std::cerr<<adresse.toStdString();

    QUrl url(adresse);
    QNetworkRequest req(url);
    QNetworkReply * reply = manager.get(req);
    eventLoop.exec();
    QString reponse = (QString)reply->readAll();
    if(reponse.size() < 2 )
        {
        QMessageBox mess(QMessageBox::Warning, "ATTENTION", "L'envoi n'a pas été valide.");
        mess.exec();
        }
    else
        {
        ui->b_envoi->setVisible(false);
        ui->b_enregistrer->setVisible(true);
        ui->t_nom->setVisible(true);
        jeton=reponse.toStdString();
        }
    }

void fenetre::save()
    {
    // Réseau
    QEventLoop eventLoop;
    QNetworkAccessManager manager;
    connect(&manager, SIGNAL(finished(QNetworkReply*)), &eventLoop, SLOT(quit()));

    // Construction de la requête http
    QString adresse = url;
    adresse += "xpfight_server.php?jeton=";
    // Passage du jeton
    adresse += jeton.c_str();
    adresse += "&nom=";
    adresse += ui->t_nom->text();
    QUrl url(adresse);
    QNetworkRequest req(url);
    QNetworkReply * reply = manager.get(req);
    eventLoop.exec();
    QString reponse = (QString)reply->readAll();
    // Lecture du score en xml

    //DEBUG
    std::cerr<<reponse.toStdString();



    //DEBUG
    /*
    if(reponse !="0")
        {
        QXmlStreamReader xml(reponse);
        QMessageBox mess(QMessageBox::Information, "Information", "Votre score est enregistré.");
        mess.exec();
        }
    else
        {
        QMessageBox mess(QMessageBox::Warning, "ATTENTION", "Votre score n'a pas été enregistré.");
        mess.exec();
        }
    */
    init();
    }

void fenetre::quitter()
    {
    QMessageBox mess;
    int r=0;
    mess.setText("Merci d'avoir utilisé XPFIGHT.");
    mess.setInformativeText("Mais êtes-vous sûr de vouloir quitter le jeu ?");
    mess.setStandardButtons(QMessageBox::Cancel | QMessageBox::Ok);
    mess.setDefaultButton(QMessageBox::Cancel);
    mess.setIcon(QMessageBox::Question);
    r = mess.exec();
    if(r == QMessageBox::Ok)
        {
        QApplication::quit();
        }
    }

void fenetre::aide()
    {
    class aide a;
    a.exec();
    }

void fenetre::a_propos()
    {


    }

void fenetre::changer_theme()
    {
    QString s = qobject_cast<QAction *>(sender())->text();
    theme = s;
    init();
    }
