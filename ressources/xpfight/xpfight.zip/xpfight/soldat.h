#ifndef SOLDAT_H
#define SOLDAT_H

#include "perso.h"

class soldat : public perso
    {
    private:
        QString theme;

    public:
        soldat(QString ="classique");
        unsigned int fight(std::array <perso *, 100>&);
    };

#endif // SOLDAT_H
