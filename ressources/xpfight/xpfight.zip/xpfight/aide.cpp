#include "aide.h"
#include "ui_aide.h"

aide::aide(QWidget *parent) : QDialog(parent), ui(new Ui::aide)
    {
    ui->setupUi(this);
    connect(ui->bb_aide, &QDialogButtonBox::accepted, this, &QDialog::accept);
    connect(ui->bb_aide, &QDialogButtonBox::rejected, this, &QDialog::reject);
    }

aide::~aide()
    {
    delete ui;
    }
