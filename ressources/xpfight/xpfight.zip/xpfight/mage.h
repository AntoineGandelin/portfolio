#ifndef MAGE_H
#define MAGE_H

#include "perso.h"

class mage : public perso
    {
    private:
        QString theme;

    public:
        mage(QString ="classique");
        unsigned int fight(std::array <perso *, 100>&);
    };

#endif // MAGE_H
