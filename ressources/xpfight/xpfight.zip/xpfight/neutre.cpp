#include "neutre.h"

neutre::neutre(QString theme) : perso()
    {
    QPixmap pic;
    QString fic_im = "neutre.png";
    fic_im = "themes/" + theme + "/" + fic_im;
    pic.load(fic_im);
    setPixmap(pic);
    }

unsigned int neutre::fight(std::array <perso *, 100>& a)
    {
    return 0;
    }
