#include "monstre.h"

monstre::monstre(QString theme) : perso()
    {
    QPixmap pic;
    QString fic_im = "monstre.png";
    fic_im = "themes/" + theme + "/" + fic_im;
    pic.load(fic_im);
    setPixmap(pic);
    set_val(9);
    }

unsigned int monstre::fight(std::array <perso *, 100>& a)
    {
    return 0;
    }
