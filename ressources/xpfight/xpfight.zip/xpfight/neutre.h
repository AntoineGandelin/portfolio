#ifndef NEUTRE_H
#define NEUTRE_H

#include "perso.h"

class neutre : public perso
    {
    public:
        neutre(QString ="classique");
        unsigned int fight(std::array <perso *, 100>&);
    };

#endif // NEUTRE_H
