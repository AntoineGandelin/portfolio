#ifndef PERSO_H
#define PERSO_H

#include <QLabel>
#include <QWidget>
#include <QObject>
#include <QMessageBox>
#include <QMouseEvent>
#include <QPixmap>
#include <array>
#include <QString>

class perso : public QLabel
    {
    Q_OBJECT

    signals:
        void clicked(int);

    public:
        perso();
        ~perso();
        virtual unsigned int fight(std::array <perso *, 100>&)=0;
        void set_val(unsigned int);
        void set_position(unsigned int);
        unsigned int get_val();
        unsigned int get_position();

    protected:
        void mousePressEvent(QMouseEvent *);

    private:
        unsigned int val;
        unsigned int pos;
    };

#endif // PERSO_H
