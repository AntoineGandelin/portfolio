#ifndef MONSTRE_H
#define MONSTRE_H

#include "perso.h"

class monstre : public perso
    {
    public:
        monstre(QString ="classique");
        unsigned int fight(std::array <perso *, 100>&);
    };

#endif // MONSTRE_H
