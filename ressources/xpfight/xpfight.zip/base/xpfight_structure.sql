begin transaction;

create table score
	(
	id_score	serial primary key,
	pseudo		varchar(20),
	date_score	timestamp,
	ip		inet,
	grille		integer,
	nb_tues		integer,
	perso1		char(1) check (perso1 in ('A', 'M', 'S')),
	perso2		char(1) check (perso2 in ('A', 'M', 'S')),
	perso3		char(1) check (perso3 in ('A', 'M', 'S')),
	pos1		integer,
	pos2		integer,
	pos3		integer
	);
commit;
