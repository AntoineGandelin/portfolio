create database xpfight;
create role xpfight_admin password 'admin' login;
grant all on database xpfight to xpfight_admin;
