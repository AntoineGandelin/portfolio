/********************************************************************************
** Form generated from reading UI file 'fenetre.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FENETRE_H
#define UI_FENETRE_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_fenetre
{
public:
    QWidget *centralwidget;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *la_titre;
    QLabel *label;
    QLabel *l_titre;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *la_commande;
    QLabel *l_numero;
    QLineEdit *t_numero;
    QPushButton *b_init;
    QSpacerItem *verticalSpacer;
    QLineEdit *t_nom;
    QPushButton *b_enregistrer;
    QPushButton *b_fight;
    QPushButton *b_envoi;
    QFrame *frame;
    QWidget *gridLayoutWidget;
    QGridLayout *la_grille;
    QMenuBar *barre_menu;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *fenetre)
    {
        if (fenetre->objectName().isEmpty())
            fenetre->setObjectName(QString::fromUtf8("fenetre"));
        fenetre->resize(921, 729);
        QIcon icon;
        icon.addFile(QString::fromUtf8("../xpfight_b/fight.png"), QSize(), QIcon::Normal, QIcon::Off);
        fenetre->setWindowIcon(icon);
        centralwidget = new QWidget(fenetre);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        horizontalLayoutWidget = new QWidget(centralwidget);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(0, 11, 921, 162));
        la_titre = new QHBoxLayout(horizontalLayoutWidget);
        la_titre->setObjectName(QString::fromUtf8("la_titre"));
        la_titre->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(horizontalLayoutWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setPixmap(QPixmap(QString::fromUtf8("../xpfight_b/fight.png")));

        la_titre->addWidget(label);

        l_titre = new QLabel(horizontalLayoutWidget);
        l_titre->setObjectName(QString::fromUtf8("l_titre"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(l_titre->sizePolicy().hasHeightForWidth());
        l_titre->setSizePolicy(sizePolicy);
        l_titre->setMinimumSize(QSize(40, 40));
        l_titre->setStyleSheet(QString::fromUtf8("font-size: 140px;\n"
"color: darkred;"));

        la_titre->addWidget(l_titre);

        verticalLayoutWidget = new QWidget(centralwidget);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(578, 200, 281, 471));
        la_commande = new QVBoxLayout(verticalLayoutWidget);
        la_commande->setObjectName(QString::fromUtf8("la_commande"));
        la_commande->setContentsMargins(0, 0, 0, 0);
        l_numero = new QLabel(verticalLayoutWidget);
        l_numero->setObjectName(QString::fromUtf8("l_numero"));
        l_numero->setStyleSheet(QString::fromUtf8("font-size:40px;\n"
"color:grey;"));
        l_numero->setAlignment(Qt::AlignCenter);
        l_numero->setWordWrap(true);

        la_commande->addWidget(l_numero);

        t_numero = new QLineEdit(verticalLayoutWidget);
        t_numero->setObjectName(QString::fromUtf8("t_numero"));
        t_numero->setStyleSheet(QString::fromUtf8("font-size:40px;\n"
"color:darkblue;"));
        t_numero->setAlignment(Qt::AlignCenter);

        la_commande->addWidget(t_numero);

        b_init = new QPushButton(verticalLayoutWidget);
        b_init->setObjectName(QString::fromUtf8("b_init"));
        b_init->setStyleSheet(QString::fromUtf8("font-size:30px;\n"
"color:darkred;"));
        b_init->setFlat(false);

        la_commande->addWidget(b_init);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        la_commande->addItem(verticalSpacer);

        t_nom = new QLineEdit(verticalLayoutWidget);
        t_nom->setObjectName(QString::fromUtf8("t_nom"));
        t_nom->setStyleSheet(QString::fromUtf8("font-size:36px;\n"
"color:darkblue;"));

        la_commande->addWidget(t_nom);

        b_enregistrer = new QPushButton(verticalLayoutWidget);
        b_enregistrer->setObjectName(QString::fromUtf8("b_enregistrer"));
        b_enregistrer->setEnabled(true);
        b_enregistrer->setMinimumSize(QSize(0, 50));
        b_enregistrer->setStyleSheet(QString::fromUtf8("font-size:24px;\n"
"color:darkred;"));

        la_commande->addWidget(b_enregistrer);

        b_fight = new QPushButton(verticalLayoutWidget);
        b_fight->setObjectName(QString::fromUtf8("b_fight"));
        b_fight->setMinimumSize(QSize(0, 50));
        b_fight->setStyleSheet(QString::fromUtf8("font-size:30px;\n"
"color:darkgreen;"));

        la_commande->addWidget(b_fight);

        b_envoi = new QPushButton(verticalLayoutWidget);
        b_envoi->setObjectName(QString::fromUtf8("b_envoi"));
        b_envoi->setEnabled(true);
        b_envoi->setMinimumSize(QSize(0, 50));
        b_envoi->setStyleSheet(QString::fromUtf8("font-size:24px;\n"
"color:darkred;"));

        la_commande->addWidget(b_envoi);

        frame = new QFrame(centralwidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(60, 220, 451, 451));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        gridLayoutWidget = new QWidget(frame);
        gridLayoutWidget->setObjectName(QString::fromUtf8("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(10, 10, 391, 331));
        la_grille = new QGridLayout(gridLayoutWidget);
        la_grille->setSpacing(3);
        la_grille->setObjectName(QString::fromUtf8("la_grille"));
        la_grille->setSizeConstraint(QLayout::SetFixedSize);
        la_grille->setContentsMargins(0, 0, 0, 0);
        fenetre->setCentralWidget(centralwidget);
        barre_menu = new QMenuBar(fenetre);
        barre_menu->setObjectName(QString::fromUtf8("barre_menu"));
        barre_menu->setGeometry(QRect(0, 0, 921, 23));
        fenetre->setMenuBar(barre_menu);
        statusbar = new QStatusBar(fenetre);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        fenetre->setStatusBar(statusbar);

        retranslateUi(fenetre);

        QMetaObject::connectSlotsByName(fenetre);
    } // setupUi

    void retranslateUi(QMainWindow *fenetre)
    {
        fenetre->setWindowTitle(QCoreApplication::translate("fenetre", "XPFIGHT", nullptr));
        label->setText(QString());
        l_titre->setText(QCoreApplication::translate("fenetre", "XPFIGHT", nullptr));
        l_numero->setText(QCoreApplication::translate("fenetre", "N\302\260 de grille", nullptr));
        t_numero->setText(QString());
#if QT_CONFIG(whatsthis)
        b_init->setWhatsThis(QCoreApplication::translate("fenetre", "<html><head/><body><p>Pour r\303\251initialiser le jeu.</p></body></html>", nullptr));
#endif // QT_CONFIG(whatsthis)
        b_init->setText(QCoreApplication::translate("fenetre", "Initialiser", nullptr));
        t_nom->setText(QString());
        b_enregistrer->setText(QCoreApplication::translate("fenetre", "Enregister votre score", nullptr));
        b_fight->setText(QCoreApplication::translate("fenetre", "FIGHT !", nullptr));
        b_envoi->setText(QCoreApplication::translate("fenetre", "V\303\251rifier le score", nullptr));
    } // retranslateUi

};

namespace Ui {
    class fenetre: public Ui_fenetre {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FENETRE_H
