/********************************************************************************
** Form generated from reading UI file 'aide.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AIDE_H
#define UI_AIDE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_aide
{
public:
    QDialogButtonBox *bb_aide;
    QLabel *l_titre;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *vl_chap_1;
    QLabel *l_chap_1_titre;
    QLabel *l_chap_1;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *vl_chap_2;
    QLabel *l_chap_2_titre;
    QLabel *l_chap_2;
    QWidget *verticalLayoutWidget_4;
    QVBoxLayout *vl_chap_3;
    QLabel *l_chap_3_titre;
    QLabel *l_chap_3;

    void setupUi(QWidget *aide)
    {
        if (aide->objectName().isEmpty())
            aide->setObjectName(QString::fromUtf8("aide"));
        aide->resize(879, 959);
        aide->setMinimumSize(QSize(500, 500));
        bb_aide = new QDialogButtonBox(aide);
        bb_aide->setObjectName(QString::fromUtf8("bb_aide"));
        bb_aide->setGeometry(QRect(690, 30, 168, 27));
        bb_aide->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        l_titre = new QLabel(aide);
        l_titre->setObjectName(QString::fromUtf8("l_titre"));
        l_titre->setGeometry(QRect(20, 10, 701, 61));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(l_titre->sizePolicy().hasHeightForWidth());
        l_titre->setSizePolicy(sizePolicy);
        l_titre->setMinimumSize(QSize(40, 40));
        l_titre->setLayoutDirection(Qt::LeftToRight);
        l_titre->setStyleSheet(QString::fromUtf8("font-size: 50px;\n"
"font-weight: bold;\n"
""));
        l_titre->setAlignment(Qt::AlignCenter);
        scrollArea = new QScrollArea(aide);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        scrollArea->setEnabled(true);
        scrollArea->setGeometry(QRect(20, 100, 840, 840));
        scrollArea->setWidgetResizable(true);
        scrollArea->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 824, 2000));
        scrollAreaWidgetContents->setMinimumSize(QSize(800, 2000));
        verticalLayoutWidget = new QWidget(scrollAreaWidgetContents);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(0, 0, 821, 111));
        vl_chap_1 = new QVBoxLayout(verticalLayoutWidget);
        vl_chap_1->setObjectName(QString::fromUtf8("vl_chap_1"));
        vl_chap_1->setContentsMargins(20, 0, 20, 0);
        l_chap_1_titre = new QLabel(verticalLayoutWidget);
        l_chap_1_titre->setObjectName(QString::fromUtf8("l_chap_1_titre"));
        l_chap_1_titre->setMinimumSize(QSize(0, 50));
        l_chap_1_titre->setStyleSheet(QString::fromUtf8("color: #a01040;\n"
"font-size:30px;\n"
"font-weight: bold;"));

        vl_chap_1->addWidget(l_chap_1_titre);

        l_chap_1 = new QLabel(verticalLayoutWidget);
        l_chap_1->setObjectName(QString::fromUtf8("l_chap_1"));
        l_chap_1->setMinimumSize(QSize(0, 0));
        l_chap_1->setStyleSheet(QString::fromUtf8("font-size:20px;"));
        l_chap_1->setTextFormat(Qt::PlainText);

        vl_chap_1->addWidget(l_chap_1);

        verticalLayoutWidget_2 = new QWidget(scrollAreaWidgetContents);
        verticalLayoutWidget_2->setObjectName(QString::fromUtf8("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(0, 116, 821, 141));
        vl_chap_2 = new QVBoxLayout(verticalLayoutWidget_2);
        vl_chap_2->setObjectName(QString::fromUtf8("vl_chap_2"));
        vl_chap_2->setContentsMargins(20, 0, 20, 0);
        l_chap_2_titre = new QLabel(verticalLayoutWidget_2);
        l_chap_2_titre->setObjectName(QString::fromUtf8("l_chap_2_titre"));
        l_chap_2_titre->setMinimumSize(QSize(0, 50));
        l_chap_2_titre->setStyleSheet(QString::fromUtf8("color: #a01040;\n"
"font-size:30px;\n"
"font-weight: bold;"));

        vl_chap_2->addWidget(l_chap_2_titre);

        l_chap_2 = new QLabel(verticalLayoutWidget_2);
        l_chap_2->setObjectName(QString::fromUtf8("l_chap_2"));
        l_chap_2->setMinimumSize(QSize(0, 80));
        l_chap_2->setStyleSheet(QString::fromUtf8("font-size:20px;"));
        l_chap_2->setTextFormat(Qt::PlainText);
        l_chap_2->setAlignment(Qt::AlignJustify|Qt::AlignVCenter);
        l_chap_2->setWordWrap(true);

        vl_chap_2->addWidget(l_chap_2);

        verticalLayoutWidget_4 = new QWidget(scrollAreaWidgetContents);
        verticalLayoutWidget_4->setObjectName(QString::fromUtf8("verticalLayoutWidget_4"));
        verticalLayoutWidget_4->setGeometry(QRect(0, 260, 821, 231));
        vl_chap_3 = new QVBoxLayout(verticalLayoutWidget_4);
        vl_chap_3->setObjectName(QString::fromUtf8("vl_chap_3"));
        vl_chap_3->setContentsMargins(20, 0, 20, 0);
        l_chap_3_titre = new QLabel(verticalLayoutWidget_4);
        l_chap_3_titre->setObjectName(QString::fromUtf8("l_chap_3_titre"));
        l_chap_3_titre->setMinimumSize(QSize(0, 50));
        l_chap_3_titre->setStyleSheet(QString::fromUtf8("color: #a01040;\n"
"font-size:30px;\n"
"font-weight: bold;"));

        vl_chap_3->addWidget(l_chap_3_titre);

        l_chap_3 = new QLabel(verticalLayoutWidget_4);
        l_chap_3->setObjectName(QString::fromUtf8("l_chap_3"));
        l_chap_3->setMinimumSize(QSize(0, 80));
        l_chap_3->setStyleSheet(QString::fromUtf8("font-size:20px;"));
        l_chap_3->setTextFormat(Qt::PlainText);
        l_chap_3->setAlignment(Qt::AlignJustify|Qt::AlignVCenter);
        l_chap_3->setWordWrap(true);

        vl_chap_3->addWidget(l_chap_3);

        scrollArea->setWidget(scrollAreaWidgetContents);

        retranslateUi(aide);

        QMetaObject::connectSlotsByName(aide);
    } // setupUi

    void retranslateUi(QWidget *aide)
    {
        aide->setWindowTitle(QCoreApplication::translate("aide", "Form", nullptr));
        l_titre->setText(QCoreApplication::translate("aide", "R\303\250gles du jeu", nullptr));
        l_chap_1_titre->setText(QCoreApplication::translate("aide", "But du jeu", nullptr));
        l_chap_1->setText(QCoreApplication::translate("aide", "Des monstres attaquent votre village !\n"
"Vous devez le prot\303\250ger ! Utilisez vos troupes pour prot\303\250ger votre village.", nullptr));
        l_chap_2_titre->setText(QCoreApplication::translate("aide", "Objectifs du jeu", nullptr));
        l_chap_2->setText(QCoreApplication::translate("aide", "Le village est repr\303\251sent\303\251 par un terrain de 10 X 10 cases. Sur ce terrain sont dispos\303\251s 10 monstres. Vous devez placer sur le terrain un ensemble de 3 troupes pour tuer le maximum de monstres.", nullptr));
        l_chap_3_titre->setText(QCoreApplication::translate("aide", "D\303\251roulement de la partie", nullptr));
        l_chap_3->setText(QCoreApplication::translate("aide", "Le num\303\251ro de carte correspond \303\240 une disposition de monstres. Par exemple, \303\240 chaque fois que vous jouerez avec le num\303\251ro 100, vos monstres auront toujours la m\303\252me position. \n"
"Vous pouvez \303\240 tout moment changer ce num\303\251ro et gr\303\242ce au bouton, [initialiser] choisir une autre disposition de monstres.\n"
"Au d\303\251but de la partie, une disposition al\303\251atoire appara\303\256t correpondant \303\240 un num\303\251ro entre  1 et 100, mais vous pouvez aller au del\303\240.", nullptr));
    } // retranslateUi

};

namespace Ui {
    class aide: public Ui_aide {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AIDE_H
