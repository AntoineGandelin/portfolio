for fic in $*
do
	./fix2csv $fic
done
