<?php

/* DÃ©roulement de l'Ã©valuation : Vous allez devoir rÃ©aliser un passage de fichiers JSON en CSV Ã  lâ€™aide dâ€™un programme rÃ©alisÃ© avec le langage PHP.
Lâ€™objectif Ã©tant dâ€™approfondir vos connaissances ainsi que vos compÃ©tences en PHP mais Ã©galement au niveau de la manipulation des donnÃ©es au sein dâ€™un fichier JSON/CSV. 
ComplÃ©ter le programme suivant (en vous aidant de la documentation PHP) en respectant la structure du CSV : 
Code Insee / Code postal / Commune / Nombre habitants / Rue / Ordures / Recurrence / Tri / Recurrence 
Vous devez remplacer tous les "..." */

// Emplacement du fichier
$file = fopen('json_clermont.json', 'r');

// Lecture entiÃ¨re du fichier
$content = fread($file, filesize('json_clermont.json')

// Ouverture du fichier 
$file2 = fopen('json_clermont.csv', 'w');

// DÃ©codage de la chaÃ®ne JSON
$datasets = json_decode($content, true);

// Formatage de plusieurs ligne en CSV et Ã©criture dans le fichier
foreach($datasets as $i)
	{
   fputcsv($file, $i)
   [
    'Code Insee / Code postal / Commune / Nombre habitants / Rue / Ordures / Recurrence / Tri / Recurrence'
    ]);
 	};

/*foreach ($datasets as $dataset) 
    {

    /* BONUS : SÃ©parez les jours et horaires des ordures mÃ©nagÃ¨res et du tri sÃ©lectif en deux colonnes dans le fichier CSV.
    De ce fait, la structure du CSV devra donc Ãªtre : 
    Code Insee / Code postal / Commune / Nombre habitants / Rue / Ordures / Horaires ordures / Recurrence / Tri / Horaires tri / Recurrence

    Aide : Utilisation de la fonction explode permet de scinder une chaÃ®ne de caractÃ¨res en segments
    explode(...);

    Utilisation de la fonction preg_match_all (expression rationnelle globale) 
    et des expressions rÃ©guliÃ¨res (chaÃ®nes de caractÃ¨res, qui dÃ©crivent, selon une syntaxe prÃ©cise, 
    un ensemble de chaÃ®nes de caractÃ¨res possibles)
    preg_match_all(...); */

    /*...($file2, 
        [
        ...(' ... ', 1),
        ...(' ... ', 1),
        ...,
        ...(' ... ', 1),
        ...,
        ...(' - ', ... ?? []),
        ...(' - ', ... ?? []),
        ...(' ... ', 1),
        ...,
        ...,
        ...(' ... ', 1),
        ]);
    }*/
    ?>