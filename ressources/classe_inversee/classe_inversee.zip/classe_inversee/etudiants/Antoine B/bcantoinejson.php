<?php

/* Déroulement de l'évaluation : Vous allez devoir réaliser un passage de fichiers JSON en CSV à l’aide d’un programme réalisé avec le langage PHP.
L’objectif étant d’approfondir vos connaissances ainsi que vos compétences en PHP mais également au niveau de la manipulation des données au sein d’un fichier JSON/CSV. 
Compléter le programme suivant (en vous aidant de la documentation PHP) en respectant la structure du CSV : 
Code Insee / Code postal / Commune / Nombre habitants / Rue / Ordures / Recurrence / Tri / Recurrence 
Vous devez remplacer tous les "..." */

// Emplacement du fichier
$file = "json_clermont.json";

// Lecture entière du fichier
$content = file_get_contents($file);

// Ouverture du fichier 
$file2 = fopen($content,"r");

// Décodage de la chaîne JSON
$datasets = json_decode($file2,true);

// Formatage de plusieurs ligne en CSV et écriture dans le fichier
$sortie=fputcsv($file2, 
    [
        "Code_Insee", 
        "Code_postal", 
        "Commune", 
        "Nombre_habitants",
        "Rue",
        "Ordures",  
        "Recurrence_Tri", 
        "Recurrence",
    ]);

var_dump($file2);
var_dump($sortie);

/* foreach ($datasets as $dataset) 
    {

    BONUS : Séparez les jours et horaires des ordures ménagères et du tri sélectif en deux colonnes dans le fichier CSV.
    De ce fait, la structure du CSV devra donc être : 
    Code Insee / Code postal / Commune / Nombre habitants / Rue / Ordures / Horaires ordures / Recurrence / Tri / Horaires tri / Recurrence

    Aide : Utilisation de la fonction explode permet de scinder une chaîne de caractères en segments
    explode(...);

    Utilisation de la fonction preg_match_all (expression rationnelle globale) 
    et des expressions régulières (chaînes de caractères, qui décrivent, selon une syntaxe précise, 
    un ensemble de chaînes de caractères possibles)
    preg_match_all(...); 

    ...($file2, 
        [
        ...(' ... ', 1),
        ...(' ... ', 1),
        ...,
        ...(' ... ', 1),
        ...,
        ...(' - ', ... ?? []),
        ...(' - ', ... ?? []),
        ...(' ... ', 1),
        ...,
        ...,
        ...(' ... ', 1),
        ]);
    }*/


    /*
        "code_insee",
        "code_postal",
        "nb_habitants",
        "commune",
        "voie",
        "ordures_menagers_jours",
        "ordures_menagers_periode",
        "ordures_menagers_observations",
        "dechets_recyclables_jours",
        "dechets_recyclables_periode",
        "dechets_recyclables_observations",
        "dechets_vegeteaux_periodes",
        "dechets_vegeteaux_jours",
        "dechets_vegeteaux_observations",
        "emcombrants_periode",
        "emcombrants_jours",
        "emcombrants_observations",
        "verre_periode",
        "verre_jours",
        "verre_observations",
        "deee_periode",
        "deee_jours",
        "deee_observations",
        "gravats_periode",
        "gravats_jours",
        "gravats_observations",
        "dechets_toxique_periode",
        "dechets_toxique_jours",
        "dechets_toxique_observations",
        "nom"*/
