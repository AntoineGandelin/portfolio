<?php
	$r = json_decode(implode(file("json_clermont.json")), true);
	$insee = $r['code_insee'];
	$voies = $r['voies'];
	$s='';
	foreach($voies as $voie)
		{
		$s = $s.$insee.','.$voie['voie']."\n";		
		}
	file_put_contents('sortie.csv',$s);		
?>
