/********************************************************************************
** Form generated from reading UI file 'fenetre.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FENETRE_H
#define UI_FENETRE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_fenetre
{
public:
    QWidget *centralwidget;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *general;
    QLabel *detail;
    QFrame *line;
    QLineEdit *affichage;
    QGridLayout *grille;

    void setupUi(QMainWindow *fenetre)
    {
        if (fenetre->objectName().isEmpty())
            fenetre->setObjectName(QString::fromUtf8("fenetre"));
        fenetre->resize(260, 382);
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        fenetre->setFont(font);
        fenetre->setStyleSheet(QString::fromUtf8(""));
        centralwidget = new QWidget(fenetre);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayoutWidget = new QWidget(centralwidget);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(20, 20, 221, 341));
        general = new QVBoxLayout(verticalLayoutWidget);
        general->setObjectName(QString::fromUtf8("general"));
        general->setContentsMargins(0, 0, 0, 0);
        detail = new QLabel(verticalLayoutWidget);
        detail->setObjectName(QString::fromUtf8("detail"));
        detail->setMaximumSize(QSize(219, 20));

        general->addWidget(detail);

        line = new QFrame(verticalLayoutWidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        general->addWidget(line);

        affichage = new QLineEdit(verticalLayoutWidget);
        affichage->setObjectName(QString::fromUtf8("affichage"));
        affichage->setStyleSheet(QString::fromUtf8("background-color: white;"));
        affichage->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        general->addWidget(affichage);

        grille = new QGridLayout();
        grille->setObjectName(QString::fromUtf8("grille"));

        general->addLayout(grille);

        fenetre->setCentralWidget(centralwidget);

        retranslateUi(fenetre);

        QMetaObject::connectSlotsByName(fenetre);
    } // setupUi

    void retranslateUi(QMainWindow *fenetre)
    {
        fenetre->setWindowTitle(QCoreApplication::translate("fenetre", "Calculatrix", nullptr));
        detail->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class fenetre: public Ui_fenetre {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FENETRE_H
